package com.example.omnia.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

enum class NavigationTab(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    HOME(
        title = "Core",
        icon = Icons.Default.Radar,
        testTag = "nav_tab_home"
    ),
    WORKSPACE(
        title = "Workspace",
        icon = Icons.Default.Layers,
        testTag = "nav_tab_workspace"
    ),
    TASKS(
        title = "Tasks",
        icon = Icons.Default.Hub,
        testTag = "nav_tab_tasks"
    ),
    BUSINESS(
        title = "Business",
        icon = Icons.Default.Apartment,
        testTag = "nav_tab_business"
    ),
    MEMORY(
        title = "Memory",
        icon = Icons.Default.Memory,
        testTag = "nav_tab_memory"
    ),
    SETTINGS(
        title = "Settings",
        icon = Icons.Default.Settings,
        testTag = "nav_tab_settings"
    )
}
