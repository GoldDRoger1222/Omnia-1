package com.omnia.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.omnia.ui.components.AiCoreCanvas
import com.example.omnia.ui.components.DeveloperControlPanel
import com.example.omnia.ui.components.ParticleCanvas
import com.example.omnia.ui.components.SystemStatusCard
import com.example.omnia.ui.components.TaskActivityPanel
import com.example.omnia.ui.components.TextCommandInput
import com.example.omnia.ui.components.VoiceActivationButton
import com.example.omnia.viewmodel.OmniaScreen
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaAmber
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCrimson
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily
import com.omnia.app.core.OmniaLocalization
import com.omnia.app.ui.components.OmniaHeader

@Composable
fun MainDashboardScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val activityLogs by viewModel.activityLogs.collectAsStateWithLifecycle()
    val lastTransitionMessage by viewModel.lastTransitionMessage.collectAsStateWithLifecycle()
    val isAutoDemoRunning by viewModel.isAutoDemoRunning.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val textCommand by viewModel.textCommand.collectAsStateWithLifecycle()
    val commandFeedback by viewModel.commandFeedback.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val pendingApprovals by viewModel.pendingApprovals.collectAsStateWithLifecycle()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .testTag("main_dashboard_screen")
    ) {
        ParticleCanvas(
            state = currentState,
            particleCount = settings.particleDensity,
            enabled = settings.particlesEnabled
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                OmniaHeader(
                    title = OmniaLocalization.getString("app_title", selectedLanguage),
                    subtitle = OmniaLocalization.getString("tagline", selectedLanguage),
                    state = currentState,
                    currentLanguage = selectedLanguage,
                    onLanguageChange = { viewModel.setLanguage(it) }
                )
            }

            // Pending Approvals Banner (Controlled Autonomy Gate)
            if (pendingApprovals.isNotEmpty()) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo(OmniaScreen.SECURITY_CENTER) }
                            .testTag("banner_pending_approval"),
                        shape = RoundedCornerShape(10.dp),
                        color = OmniaDarkNavy,
                        border = BorderStroke(1.5.dp, OmniaAmber)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Alert",
                                tint = OmniaAmber,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = OmniaLocalization.getString("approval_required", selectedLanguage),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontFamily = OrbitronFamily,
                                        color = OmniaAmber,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "${pendingApprovals.size} action(s) awaiting your explicit confirmation",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = RajdhaniFamily,
                                        color = OmniaTextPrimary,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                            Text(
                                text = "REVIEW >",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = OrbitronFamily,
                                    color = OmniaAmber,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            // Central AI Core
            item {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    AiCoreCanvas(
                        state = currentState,
                        size = 210.dp,
                        speedMultiplier = settings.corePulseSpeed,
                        onClick = { viewModel.onVoiceButtonClick() }
                    )
                }

                // Core State Display
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = currentState.displayName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = OrbitronFamily,
                            color = currentState.accentColor,
                            letterSpacing = 1.8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = currentState.description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextSecondary,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            // Voice & Text Command Console
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    VoiceActivationButton(
                        state = currentState,
                        onClick = { viewModel.onVoiceButtonClick() }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TextCommandInput(
                        value = textCommand,
                        onValueChange = { viewModel.onTextCommandChange(it) },
                        onSubmit = { viewModel.executeTextCommand() },
                        state = currentState,
                        feedback = commandFeedback
                    )
                }
            }

            // Multilingual Quick Directive Chips
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "SUGGESTED DIRECTIVES (${selectedLanguage.name}):",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val sample1 = OmniaLocalization.getString("sample_cmd_1", selectedLanguage)
                        val sample2 = OmniaLocalization.getString("sample_cmd_2", selectedLanguage)
                        val sample3 = "RUN DIAGNOSTICS & AUDIT"

                        items(listOf(sample1, sample2, sample3)) { cmd ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(OmniaDarkNavy)
                                    .border(1.dp, OmniaBorderBright, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.executeUserInstruction(cmd) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = cmd,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = RajdhaniFamily,
                                        color = OmniaTextPrimary,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Quick Hub Navigation Cards (Direct Access to Key Workspaces)
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "INTEGRATED OPERATOR WORKSPACES",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontSize = 11.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WorkspaceQuickCard(
                            title = "Product Studio",
                            subtitle = "AI Visual Catalog",
                            icon = Icons.Default.PhotoCamera,
                            onClick = { viewModel.navigateTo(OmniaScreen.PRODUCT_STUDIO) },
                            modifier = Modifier.weight(1f)
                        )
                        WorkspaceQuickCard(
                            title = "Social Operator",
                            subtitle = "Multilingual Posts",
                            icon = Icons.Default.Campaign,
                            onClick = { viewModel.navigateTo(OmniaScreen.SOCIAL_MEDIA_MANAGER) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WorkspaceQuickCard(
                            title = "Orders & Sales",
                            subtitle = "E-Commerce Ledger",
                            icon = Icons.Default.PointOfSale,
                            onClick = { viewModel.navigateTo(OmniaScreen.ORDER_MANAGEMENT) },
                            modifier = Modifier.weight(1f)
                        )
                        WorkspaceQuickCard(
                            title = "Security Center",
                            subtitle = "L0-L4 Autonomy Gate",
                            icon = Icons.Default.Security,
                            onClick = { viewModel.navigateTo(OmniaScreen.SECURITY_CENTER) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Developer State Controls
            item {
                DeveloperControlPanel(
                    currentState = currentState,
                    isAutoDemoRunning = isAutoDemoRunning,
                    lastTransitionMessage = lastTransitionMessage,
                    onStateSelect = { target -> viewModel.transitionState(target, force = true) },
                    onToggleAutoDemo = { viewModel.toggleAutoDemo() },
                    onReset = { viewModel.resetCore() }
                )
            }

            // System Telemetry Card
            item {
                SystemStatusCard(
                    telemetry = telemetry,
                    state = currentState
                )
            }

            // Live Activity Panel
            item {
                TaskActivityPanel(
                    logs = activityLogs,
                    maxHeight = 160
                )
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun WorkspaceQuickCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = OmniaCyanPrimary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaTextPrimary,
                        fontSize = 11.sp
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        color = OmniaTextMuted,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}
