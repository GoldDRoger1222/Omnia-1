package com.omnia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeviceHub
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.omnia.model.OperatorState
import com.example.omnia.ui.components.AiCoreCanvas
import com.example.omnia.ui.components.VoiceActivationButton
import com.example.omnia.viewmodel.OmniaScreen
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaAmber
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCrimson
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily
import com.omnia.app.security.PlannedAction
import com.omnia.app.security.RiskLevel
import com.omnia.app.ui.components.OmniaHeader

// ==========================================
// 1. TASK PLANNER SCREEN
// ==========================================
@Composable
fun TaskPlannerScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val activePlan by viewModel.activePlan.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OmniaHeader(
                title = "TASK PLANNER",
                subtitle = "STRUCTURED DECOMPOSITION & RISK CLASSIFICATION",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
            )
        }

        if (activePlan == null) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = OmniaSurface,
                    border = BorderStroke(1.dp, OmniaBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = OmniaCyanPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "NO ACTIVE EXECUTION PLAN",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Issue an instruction like 'OMNIA, ei dress er product campaign ready kor' to see automated reasoning and security planning in action.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextSecondary
                            ),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            val plan = activePlan!!
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = OmniaDarkNavy,
                    border = BorderStroke(1.dp, OmniaCyanPrimary.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "PLAN ID: ${plan.planId.take(8)}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = OrbitronFamily,
                                    color = OmniaCyanPrimary
                                )
                            )
                            RiskLevelBadge(risk = plan.highestRiskLevel)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Prompt: \"${plan.userPrompt}\"",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = RajdhaniFamily,
                                fontWeight = FontWeight.Bold,
                                color = OmniaTextPrimary
                            )
                        )
                        Text(
                            text = "Category: ${plan.intent.category.name} • Actions: ${plan.actions.size}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextMuted
                            )
                        )
                    }
                }
            }

            item {
                Text(
                    text = "DECOMPOSED ACTIONS (${plan.actions.size}):",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaCyanPrimary
                    )
                )
            }

            items(plan.actions, key = { it.id }) { action ->
                PlannedActionCard(action = action)
            }
        }
    }
}

@Composable
fun PlannedActionCard(action: PlannedAction) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (action.riskLevel.requiresApproval) OmniaAmber else OmniaEmerald)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = action.targetModule,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontSize = 10.sp
                        )
                    )
                }
                RiskLevelBadge(risk = action.riskLevel)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = action.title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = RajdhaniFamily,
                    fontWeight = FontWeight.Bold,
                    color = OmniaTextPrimary
                )
            )
            Text(
                text = action.payloadSummary,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = RajdhaniFamily,
                    color = OmniaTextSecondary,
                    fontSize = 12.sp
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Status: ${action.status.name}",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = RajdhaniFamily,
                    color = if (action.status.name.contains("APPROVED") || action.status.name.contains("COMPLETED")) OmniaEmerald else OmniaAmber,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
fun RiskLevelBadge(risk: RiskLevel) {
    val color = when (risk) {
        RiskLevel.L0 -> OmniaEmerald
        RiskLevel.L1 -> OmniaCyanPrimary
        RiskLevel.L2 -> OmniaAmber
        RiskLevel.L3 -> OmniaCrimson
        RiskLevel.L4 -> OmniaCrimson
    }
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = OmniaDarkNavy,
        border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
    ) {
        Text(
            text = risk.code,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = OrbitronFamily,
                fontWeight = FontWeight.Bold,
                color = color,
                fontSize = 9.sp
            )
        )
    }
}

// ==========================================
// 2. APP INTEGRATIONS SCREEN
// ==========================================
@Composable
fun AppIntegrationsScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val supportedApps by viewModel.supportedApps.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OmniaHeader(
                title = "APP INTEGRATIONS",
                subtitle = "ANDROID INTENT BROKER & DRIVER ADAPTERS",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
            )
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "SAFETY POLICY: OFFICIAL INTEGRATIONS ONLY",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "OMNIA uses standard Android Intents and official platform APIs. No unauthorized background injection or password extraction is ever attempted.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextSecondary
                        )
                    )
                }
            }
        }

        item {
            Text(
                text = "SUPPORTED APPLICATION ADAPTERS:",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary
                )
            )
        }

        items(supportedApps, key = { it.packageName }) { app ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = app.appName,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontFamily = RajdhaniFamily,
                                    fontWeight = FontWeight.Bold,
                                    color = OmniaTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(3.dp),
                                color = OmniaDarkNavy,
                                border = BorderStroke(1.dp, if (app.isInstalled) OmniaEmerald else OmniaTextMuted)
                            ) {
                                Text(
                                    text = if (app.isInstalled) "INSTALLED" else "UNAVAILABLE",
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = OrbitronFamily,
                                        color = if (app.isInstalled) OmniaEmerald else OmniaTextMuted,
                                        fontSize = 8.sp
                                    )
                                )
                            }
                        }
                        Text(
                            text = app.packageName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }

                    if (app.isInstalled) {
                        Button(
                            onClick = { viewModel.launchApp(app.packageName) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = OmniaCyanPrimary,
                                contentColor = OmniaVoidBlack
                            ),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Launch,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("LAUNCH", fontFamily = OrbitronFamily, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. VOICE WORKSPACE SCREEN
// ==========================================
@Composable
fun VoiceWorkspaceScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val lastSpoken by viewModel.voiceEngine.lastSpokenText.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        OmniaHeader(
            title = "VOICE COCKPIT",
            subtitle = "SPEECH-TO-TEXT & AUDIO HARMONICS",
            state = currentState,
            currentLanguage = selectedLanguage,
            onLanguageChange = { viewModel.setLanguage(it) },
            showBackButton = true,
            onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AiCoreCanvas(
                state = currentState,
                size = 240.dp,
                onClick = { viewModel.onVoiceButtonClick() }
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = currentState.displayName,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = OrbitronFamily,
                    color = currentState.accentColor
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Text(
                    text = if (lastSpoken.isNotBlank()) "Last Spoken: \"$lastSpoken\"" else "Awaiting voice directive...",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = RajdhaniFamily,
                        color = OmniaTextPrimary
                    ),
                    modifier = Modifier.padding(14.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            VoiceActivationButton(
                state = currentState,
                onClick = { viewModel.onVoiceButtonClick() },
                size = 72.dp
            )
        }
    }
}
