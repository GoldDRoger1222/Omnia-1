package com.omnia.app.network

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

enum class ConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    FAILED
}

data class OmniaWsMessage(
    val type: String,
    val payload: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * WebSocket client connecting Android app to the FastAPI backend (/ws/omnia).
 * Features automatic exponential backoff reconnection and token header authentication.
 */
class OmniaWebSocketClient(
    private val scope: CoroutineScope,
    private val serverUrl: String = "ws://10.0.2.2:8000/ws/omnia",
    private val authToken: String = "omnia_session_token"
) : WebSocketListener() {

    private val client = OkHttpClient.Builder()
        .pingInterval(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var webSocket: WebSocket? = null
    private var reconnectJob: Job? = null
    private var reconnectAttempt = 0

    private val _connectionStatus = MutableStateFlow(ConnectionStatus.DISCONNECTED)
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus.asStateFlow()

    private val _incomingMessages = MutableStateFlow<OmniaWsMessage?>(null)
    val incomingMessages: StateFlow<OmniaWsMessage?> = _incomingMessages.asStateFlow()

    fun connect() {
        if (_connectionStatus.value == ConnectionStatus.CONNECTED || _connectionStatus.value == ConnectionStatus.CONNECTING) {
            return
        }

        _connectionStatus.value = ConnectionStatus.CONNECTING
        val request = Request.Builder()
            .url(serverUrl)
            .addHeader("Authorization", "Bearer $authToken")
            .build()

        webSocket = client.newWebSocket(request, this)
    }

    fun disconnect() {
        reconnectJob?.cancel()
        webSocket?.close(1000, "Normal closure")
        webSocket = null
        _connectionStatus.value = ConnectionStatus.DISCONNECTED
    }

    fun sendMessage(type: String, payload: String): Boolean {
        if (_connectionStatus.value != ConnectionStatus.CONNECTED) return false
        val json = """{"type":"$type","payload":"$payload","timestamp":${System.currentTimeMillis()}}"""
        return webSocket?.send(json) ?: false
    }

    override fun onOpen(webSocket: WebSocket, response: Response) {
        _connectionStatus.value = ConnectionStatus.CONNECTED
        reconnectAttempt = 0
    }

    override fun onMessage(webSocket: WebSocket, text: String) {
        _incomingMessages.value = OmniaWsMessage(
            type = "SERVER_EVENT",
            payload = text
        )
    }

    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
        webSocket.close(code, reason)
    }

    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
        _connectionStatus.value = ConnectionStatus.DISCONNECTED
    }

    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
        _connectionStatus.value = ConnectionStatus.RECONNECTING
        scheduleReconnect()
    }

    private fun scheduleReconnect() {
        reconnectJob?.cancel()
        reconnectJob = scope.launch(Dispatchers.IO) {
            reconnectAttempt++
            val backoffMs = (1000L * (1 shl reconnectAttempt.coerceAtMost(5))).coerceAtMost(30000L)
            delay(backoffMs)
            connect()
        }
    }
}
