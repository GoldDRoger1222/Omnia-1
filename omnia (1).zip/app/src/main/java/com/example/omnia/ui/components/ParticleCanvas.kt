package com.example.omnia.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.omnia.model.OperatorState
import com.example.ui.theme.OmniaCyanPrimary
import kotlin.random.Random

data class Particle(
    val initialXRatio: Float,
    val initialYRatio: Float,
    val speed: Float,
    val radiusDp: Float,
    val baseAlpha: Float,
    val seed: Float
)

@Composable
fun ParticleCanvas(
    modifier: Modifier = Modifier,
    state: OperatorState = OperatorState.IDLE,
    particleCount: Int = 45,
    enabled: Boolean = true
) {
    if (!enabled) return

    val particles = remember(particleCount) {
        val rand = Random(42)
        List(particleCount) {
            Particle(
                initialXRatio = rand.nextFloat(),
                initialYRatio = rand.nextFloat(),
                speed = 0.2f + rand.nextFloat() * 0.8f,
                radiusDp = 1.0f + rand.nextFloat() * 2.0f,
                baseAlpha = 0.15f + rand.nextFloat() * 0.5f,
                seed = rand.nextFloat() * 1000f
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "particle_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particle_phase"
    )

    val color = state.accentColor

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        for (p in particles) {
            // Drift upward and slight sway horizontally
            val currentY = (p.initialYRatio - (phase * p.speed)) % 1f
            val normalizedY = if (currentY < 0f) currentY + 1f else currentY
            val swayX = (kotlin.math.sin((phase * 2 * kotlin.math.PI + p.seed).toDouble()).toFloat()) * 0.03f
            val currentX = (p.initialXRatio + swayX).coerceIn(0f, 1f)

            val px = currentX * w
            val py = normalizedY * h
            val radiusPx = p.radiusDp * density

            // Slight twinkle alpha
            val twinkle = (0.7f + 0.3f * kotlin.math.sin((phase * 6 * kotlin.math.PI + p.seed).toDouble()).toFloat())
            val alpha = (p.baseAlpha * twinkle).coerceIn(0.05f, 0.85f)

            drawCircle(
                color = color.copy(alpha = alpha),
                radius = radiusPx,
                center = Offset(px, py)
            )
        }
    }
}
