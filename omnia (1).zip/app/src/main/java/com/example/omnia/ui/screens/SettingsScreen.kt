package com.example.omnia.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.omnia.model.OperatorState
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCrimson
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@Composable
fun SettingsScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(16.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "OPERATOR CONFIG",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaCyanPrimary,
                        fontSize = 22.sp
                    )
                )
                Text(
                    text = "LOCAL PERSISTENCE // DATASTORE ENGINE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        letterSpacing = 1.2.sp,
                        color = OmniaTextMuted
                    )
                )
            }
        }

        // Section: Visual & Ambient Controls
        item {
            Text(
                text = "INTERFACE & VISUAL PERFORMANCE",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary,
                    fontSize = 12.sp
                )
            )
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Ambient particles toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                tint = OmniaCyanPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Subtle Ambient Particles",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = RajdhaniFamily,
                                        fontWeight = FontWeight.Bold,
                                        color = OmniaTextPrimary
                                    )
                                )
                                Text(
                                    text = "Floating sci-fi dust & energy particles",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = RajdhaniFamily,
                                        color = OmniaTextMuted
                                    )
                                )
                            }
                        }

                        Switch(
                            checked = settings.particlesEnabled,
                            onCheckedChange = { viewModel.setParticlesEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = OmniaCyanPrimary,
                                checkedTrackColor = OmniaDarkNavy,
                                uncheckedThumbColor = OmniaTextMuted,
                                uncheckedTrackColor = OmniaSurfaceElevated
                            ),
                            modifier = Modifier.testTag("switch_ambient_particles")
                        )
                    }

                    if (settings.particlesEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Particle Density: ${settings.particleDensity}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaTextSecondary,
                                fontSize = 11.sp
                            )
                        )
                        Slider(
                            value = settings.particleDensity.toFloat(),
                            onValueChange = { viewModel.setParticleDensity(it.toInt()) },
                            valueRange = 15f..80f,
                            colors = SliderDefaults.colors(
                                thumbColor = OmniaCyanPrimary,
                                activeTrackColor = OmniaCyanPrimary,
                                inactiveTrackColor = OmniaDarkNavy
                            ),
                            modifier = Modifier.testTag("slider_particle_density")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Core Pulse Speed
                    Text(
                        text = "AI Core Pulse Speed: ${String.format("%.1f", settings.corePulseSpeed)}x",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaTextSecondary,
                            fontSize = 11.sp
                        )
                    )
                    Slider(
                        value = settings.corePulseSpeed,
                        onValueChange = { viewModel.setCorePulseSpeed(it) },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = OmniaCyanPrimary,
                            activeTrackColor = OmniaCyanPrimary,
                            inactiveTrackColor = OmniaDarkNavy
                        ),
                        modifier = Modifier.testTag("slider_core_pulse_speed")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Haptic feedback toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Vibration,
                                contentDescription = null,
                                tint = OmniaCyanPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Haptic Tactile Feedback",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = RajdhaniFamily,
                                        fontWeight = FontWeight.Bold,
                                        color = OmniaTextPrimary
                                    )
                                )
                                Text(
                                    text = "Tactile impulse on state shift & voice trigger",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = RajdhaniFamily,
                                        color = OmniaTextMuted
                                    )
                                )
                            }
                        }

                        Switch(
                            checked = settings.hapticFeedbackEnabled,
                            onCheckedChange = { viewModel.setHapticFeedback(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = OmniaCyanPrimary,
                                checkedTrackColor = OmniaDarkNavy,
                                uncheckedThumbColor = OmniaTextMuted,
                                uncheckedTrackColor = OmniaSurfaceElevated
                            ),
                            modifier = Modifier.testTag("switch_haptic_feedback")
                        )
                    }
                }
            }
        }

        // Section: Operator Identity
        item {
            Text(
                text = "OPERATOR DESIGNATION",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary,
                    fontSize = 12.sp
                )
            )
        }

        item {
            var operatorNameInput by remember(settings.operatorName) { mutableStateOf(settings.operatorName) }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = operatorNameInput,
                        onValueChange = {
                            operatorNameInput = it
                            viewModel.setOperatorName(it)
                        },
                        label = { Text("Operator Unit Name", color = OmniaTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OmniaCyanPrimary,
                            unfocusedBorderColor = OmniaBorder,
                            focusedTextColor = OmniaTextPrimary,
                            unfocusedTextColor = OmniaTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_operator_name")
                    )
                }
            }
        }

        // Section: Diagnostics & Developer Tools
        item {
            Text(
                text = "DIAGNOSTICS & SYSTEM RESETS",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary,
                    fontSize = 12.sp
                )
            )
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Trigger Error State for Testing
                    OutlinedButton(
                        onClick = { viewModel.transitionState(OperatorState.ERROR, force = true) },
                        border = BorderStroke(1.dp, OmniaCrimson),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = OmniaCrimson),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_trigger_error_diag")
                    ) {
                        Icon(
                            imageVector = Icons.Default.BugReport,
                            contentDescription = null,
                            tint = OmniaCrimson,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TRIGGER TEST ANOMALY (ERROR STATE)",
                            fontFamily = OrbitronFamily,
                            fontSize = 11.sp
                        )
                    }

                    // Reset State Machine
                    OutlinedButton(
                        onClick = { viewModel.resetCore() },
                        border = BorderStroke(1.dp, OmniaCyanPrimary),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = OmniaCyanPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_reset_state_machine")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = null,
                            tint = OmniaCyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RESTORE CORE TO IDLE (STANDBY)",
                            fontFamily = OrbitronFamily,
                            fontSize = 11.sp
                        )
                    }

                    // Reset Settings to Defaults
                    OutlinedButton(
                        onClick = { viewModel.resetSettings() },
                        border = BorderStroke(1.dp, OmniaBorderBright),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = OmniaTextSecondary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_reset_settings")
                    ) {
                        Text(
                            text = "RESET PREFERENCES TO FACTORY DEFAULTS",
                            fontFamily = OrbitronFamily,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Phase 1 System Build Info
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaDarkNavy,
                border = BorderStroke(1.dp, OmniaBorder.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "OMNIA OPERATOR // SYSTEM PROFILE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Build: Phase 1.0.0-PROTOTYPE • Package: com.omnia.app • Theme: Pure Sci-Fi Dark • Persistence: AndroidX DataStore • Zero Fake Automation • Extensible Modular Architecture",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextMuted,
                            fontSize = 11.sp
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
