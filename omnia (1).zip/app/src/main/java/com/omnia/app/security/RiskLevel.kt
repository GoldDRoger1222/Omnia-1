package com.omnia.app.security

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Controlled Autonomy Risk Levels (L0 - L4)
 */
enum class RiskLevel(
    val code: String,
    val title: String,
    val requiresApproval: Boolean,
    val isProhibited: Boolean,
    val description: String
) {
    L0(
        code = "L0",
        title = "READ-ONLY & ANALYSIS",
        requiresApproval = false,
        isProhibited = false,
        description = "Read-only inspection, system status telemetry, data queries, and reporting."
    ),
    L1(
        code = "L1",
        title = "DRAFTING & REVERSIBLE",
        requiresApproval = false,
        isProhibited = false,
        description = "Local content drafting, image enhancement previews, catalog generation, and staging."
    ),
    L2(
        code = "L2",
        title = "EXTERNAL PUBLICATION",
        requiresApproval = true,
        isProhibited = false,
        description = "External social media posting, messaging, notifications, or public account updates."
    ),
    L3(
        code = "L3",
        title = "FINANCIAL & ORDERS",
        requiresApproval = true,
        isProhibited = false,
        description = "E-commerce order dispatch, ad spend budgets, payments, or consequential business transactions."
    ),
    L4(
        code = "L4",
        title = "STRICTLY PROHIBITED",
        requiresApproval = false,
        isProhibited = true,
        description = "Extraction of passwords, reading OTPs, financial PINs, biometric bypass, or security tampering."
    )
}

enum class ActionExecutionStatus {
    PENDING_EVALUATION,
    AWAITING_APPROVAL,
    APPROVED,
    REJECTED,
    EXECUTING,
    COMPLETED,
    FAILED,
    PROHIBITED_BLOCKED
}

data class PlannedAction(
    val id: String = UUID.randomUUID().toString(),
    val taskId: String,
    val title: String,
    val riskLevel: RiskLevel,
    val targetModule: String,
    val declaredPermissions: List<String> = emptyList(),
    val payloadSummary: String,
    var status: ActionExecutionStatus = ActionExecutionStatus.PENDING_EVALUATION,
    var approvalTimestamp: String? = null,
    var executedTimestamp: String? = null,
    var verificationResult: String? = null,
    val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
)

data class AuditRecord(
    val id: String = UUID.randomUUID().toString(),
    val actionId: String,
    val taskId: String,
    val riskLevel: RiskLevel,
    val actionTitle: String,
    val decision: String,
    val verified: Boolean,
    val timestamp: String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
    val previousHash: String = "0000000000000000000000000000000000000000000000000000000000000000",
    val cryptographicHash: String = ""
)

/**
 * Centralized Security Gate that enforces Controlled Autonomy.
 * The AI Planner cannot bypass this gate.
 */
class SecurityGate {
    private val auditLedger = mutableListOf<AuditRecord>()
    private var lastLedgerHash = "0000000000000000000000000000000000000000000000000000000000000000"

    fun evaluateAction(action: PlannedAction): ActionEvaluationResult {
        // Rule 1: Prohibited L4 actions are blocked unconditionally
        if (action.riskLevel == RiskLevel.L4 || action.riskLevel.isProhibited) {
            action.status = ActionExecutionStatus.PROHIBITED_BLOCKED
            logAudit(action, decision = "BLOCKED_L4_PROHIBITED", verified = false)
            return ActionEvaluationResult.Blocked(
                reason = "SECURITY POLICY VIOLATION: Action classified as L4 (Prohibited credentials/security bypass)."
            )
        }

        // Rule 2: L2 & L3 require explicit operator approval
        if (action.riskLevel.requiresApproval && action.status != ActionExecutionStatus.APPROVED) {
            action.status = ActionExecutionStatus.AWAITING_APPROVAL
            logAudit(action, decision = "AWAITING_USER_APPROVAL", verified = false)
            return ActionEvaluationResult.RequiresApproval(action)
        }

        // Rule 3: L0 & L1 or already approved L2/L3 are permitted
        action.status = ActionExecutionStatus.APPROVED
        action.approvalTimestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logAudit(action, decision = "PERMITTED_FOR_EXECUTION", verified = true)
        return ActionEvaluationResult.Permitted(action)
    }

    fun approveAction(action: PlannedAction): Boolean {
        if (action.riskLevel == RiskLevel.L4) return false
        action.status = ActionExecutionStatus.APPROVED
        action.approvalTimestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logAudit(action, decision = "USER_EXPLICIT_APPROVAL_GRANTED", verified = true)
        return true
    }

    fun rejectAction(action: PlannedAction, reason: String = "Operator rejected"): Boolean {
        action.status = ActionExecutionStatus.REJECTED
        logAudit(action, decision = "USER_REJECTED: $reason", verified = true)
        return true
    }

    fun recordVerification(action: PlannedAction, success: Boolean, details: String) {
        action.status = if (success) ActionExecutionStatus.COMPLETED else ActionExecutionStatus.FAILED
        action.verificationResult = details
        action.executedTimestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logAudit(action, decision = "VERIFIED_${if (success) "SUCCESS" else "FAILURE"}: $details", verified = success)
    }

    fun getAuditLedger(): List<AuditRecord> = auditLedger.toList()

    /**
     * Verifies the cryptographic integrity of the hash-chained audit ledger.
     * Returns true if no entries have been modified or reordered.
     */
    fun verifyLedgerIntegrity(): Boolean {
        // Entries are stored latest-first in UI list, so iterate in chronological order (reversed)
        val chronological = auditLedger.reversed()
        var expectedPrev = "0000000000000000000000000000000000000000000000000000000000000000"
        for (record in chronological) {
            if (record.previousHash != expectedPrev) return false
            val payload = "${record.previousHash}|${record.actionId}|${record.taskId}|${record.riskLevel.code}|${record.decision}|${record.verified}|${record.timestamp}"
            val calculated = sha256Hex(payload)
            if (record.cryptographicHash != calculated) return false
            expectedPrev = calculated
        }
        return true
    }

    private fun logAudit(action: PlannedAction, decision: String, verified: Boolean) {
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val prevHash = lastLedgerHash
        val payload = "$prevHash|${action.id}|${action.taskId}|${action.riskLevel.code}|$decision|$verified|$timestamp"
        val currentHash = sha256Hex(payload)
        lastLedgerHash = currentHash

        val record = AuditRecord(
            actionId = action.id,
            taskId = action.taskId,
            riskLevel = action.riskLevel,
            actionTitle = action.title,
            decision = decision,
            verified = verified,
            timestamp = timestamp,
            previousHash = prevHash,
            cryptographicHash = currentHash
        )
        auditLedger.add(0, record)
        if (auditLedger.size > 200) {
            auditLedger.removeAt(auditLedger.lastIndex)
        }
    }

    private fun sha256Hex(data: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(data.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

sealed class ActionEvaluationResult {
    data class Permitted(val action: PlannedAction) : ActionEvaluationResult()
    data class RequiresApproval(val action: PlannedAction) : ActionEvaluationResult()
    data class Blocked(val reason: String) : ActionEvaluationResult()
}
