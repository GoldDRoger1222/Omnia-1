package com.example.omnia.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.omnia.model.OperatorState
import com.example.omnia.ui.components.AiCoreCanvas
import com.example.omnia.ui.components.DeveloperControlPanel
import com.example.omnia.ui.components.ParticleCanvas
import com.example.omnia.ui.components.SystemStatusCard
import com.example.omnia.ui.components.TaskActivityPanel
import com.example.omnia.ui.components.TextCommandInput
import com.example.omnia.ui.components.VoiceActivationButton
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@Composable
fun HomeScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val activityLogs by viewModel.activityLogs.collectAsStateWithLifecycle()
    val lastTransitionMessage by viewModel.lastTransitionMessage.collectAsStateWithLifecycle()
    val isAutoDemoRunning by viewModel.isAutoDemoRunning.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val textCommand by viewModel.textCommand.collectAsStateWithLifecycle()
    val commandFeedback by viewModel.commandFeedback.collectAsStateWithLifecycle()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .testTag("home_screen")
    ) {
        // Floating subtle sci-fi particles
        ParticleCanvas(
            state = currentState,
            particleCount = settings.particleDensity,
            enabled = settings.particlesEnabled
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                OmniaHeaderBar(
                    operatorName = settings.operatorName,
                    state = currentState
                )
            }

            // Central AI Core Section
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AiCoreCanvas(
                        state = currentState,
                        size = 230.dp,
                        speedMultiplier = settings.corePulseSpeed,
                        onClick = { viewModel.onVoiceButtonClick() }
                    )
                }

                // Core State Readout Tag
                CoreStateStatusBadge(state = currentState)
            }

            // Voice & Text Command Triggers
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Voice activation button (UI trigger)
                    VoiceActivationButton(
                        state = currentState,
                        onClick = { viewModel.onVoiceButtonClick() }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Text command input
                    TextCommandInput(
                        value = textCommand,
                        onValueChange = { viewModel.onTextCommandChange(it) },
                        onSubmit = { viewModel.executeTextCommand() },
                        state = currentState,
                        feedback = commandFeedback
                    )
                }
            }

            // Developer State Machine Control Panel
            item {
                DeveloperControlPanel(
                    currentState = currentState,
                    isAutoDemoRunning = isAutoDemoRunning,
                    lastTransitionMessage = lastTransitionMessage,
                    onStateSelect = { target -> viewModel.transitionState(target, force = true) },
                    onToggleAutoDemo = { viewModel.toggleAutoDemo() },
                    onReset = { viewModel.resetCore() }
                )
            }

            // System Telemetry & Network Status
            item {
                SystemStatusCard(
                    telemetry = telemetry,
                    state = currentState
                )
            }

            // Live Task Activity Panel
            item {
                TaskActivityPanel(
                    logs = activityLogs,
                    maxHeight = 160
                )
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun OmniaHeaderBar(
    operatorName: String,
    state: OperatorState,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "OMNIA",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaCyanPrimary,
                        letterSpacing = 2.5.sp
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = OmniaDarkNavy,
                    border = BorderStroke(1.dp, OmniaBorderBright)
                ) {
                    Text(
                        text = "PHASE 1",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanGlow,
                            fontSize = 9.sp
                        )
                    )
                }
            }
            Text(
                text = "UNIVERSAL AI MOBILE OPERATOR",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = RajdhaniFamily,
                    letterSpacing = 1.2.sp,
                    color = OmniaTextMuted
                )
            )
        }

        // Live Quantum Status Pill
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = OmniaSurface,
            border = BorderStroke(1.dp, state.accentColor.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(state.accentColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = state.code,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = OrbitronFamily,
                        color = state.accentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun CoreStateStatusBadge(
    state: OperatorState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = state.displayName,
            style = MaterialTheme.typography.titleMedium.copy(
                fontFamily = OrbitronFamily,
                color = state.accentColor,
                letterSpacing = 1.8.sp,
                fontWeight = FontWeight.Bold
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = state.description,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = RajdhaniFamily,
                color = OmniaTextSecondary,
                fontSize = 12.sp
            )
        )
    }
}
