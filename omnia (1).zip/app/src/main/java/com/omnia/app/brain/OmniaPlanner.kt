package com.omnia.app.brain

import com.omnia.app.ai.HybridModelRouter
import com.omnia.app.core.OmniaLanguage
import com.omnia.app.security.PlannedAction
import com.omnia.app.security.RiskLevel
import com.omnia.app.security.SecurityGate
import java.util.UUID

enum class IntentCategory {
    PRODUCT_CAMPAIGN,
    ORDER_ANALYTICS,
    APP_AUTOMATION,
    SYSTEM_DIAGNOSTICS,
    GENERAL_QUERY,
    SECURITY_PROHIBITED
}

data class CommandIntent(
    val category: IntentCategory,
    val detectedLanguage: OmniaLanguage,
    val rawPrompt: String,
    val summary: String,
    val targetEntities: Map<String, String> = emptyMap()
)

data class ExecutionPlan(
    val planId: String = UUID.randomUUID().toString(),
    val userPrompt: String,
    val intent: CommandIntent,
    val actions: List<PlannedAction>,
    val requiresApproval: Boolean,
    val highestRiskLevel: RiskLevel
)

/**
 * OmniaPlanner decomposes natural language instructions into structured,
 * risk-classified execution actions governed by the SecurityGate.
 */
class OmniaPlanner(
    private val securityGate: SecurityGate,
    private val router: HybridModelRouter
) {

    fun interpretCommand(rawCommand: String): CommandIntent {
        val trimmed = rawCommand.trim()
        val lower = trimmed.lowercase()

        // 1. Language detection (Bangla Unicode vs Banglish vs English)
        val hasBanglaScript = lower.any { it in '\u0980'..'\u09FF' }
        val language = when {
            hasBanglaScript -> OmniaLanguage.BANGLA
            lower.contains("amar") || lower.contains("kor") || lower.contains("ajker") ||
                lower.contains("gula") || lower.contains("koro") || lower.contains("dorkar") -> OmniaLanguage.BANGLISH
            else -> OmniaLanguage.ENGLISH
        }

        // 2. Prohibited credential/OTP extraction patterns (L4 safety gate)
        if (lower.contains("password") || lower.contains("otp") || lower.contains("credit card pin") ||
            lower.contains("bypass security") || lower.contains("secret key")) {
            return CommandIntent(
                category = IntentCategory.SECURITY_PROHIBITED,
                detectedLanguage = language,
                rawPrompt = rawCommand,
                summary = "Prohibited security extraction attempt detected."
            )
        }

        // 3. Product campaign intent ("ei dress er product campaign ready kor")
        if (lower.contains("campaign") || lower.contains("dress") || lower.contains("product photo") ||
            lower.contains("product studio") || lower.contains("catalog") || lower.contains("produc")) {
            return CommandIntent(
                category = IntentCategory.PRODUCT_CAMPAIGN,
                detectedLanguage = language,
                rawPrompt = rawCommand,
                summary = "Product marketing & campaign preparation workflow.",
                targetEntities = mapOf("targetItem" to "dress", "workflow" to "social_campaign")
            )
        }

        // 4. Order analytics intent ("amar business er ajker order gula analyze kor")
        if (lower.contains("order") || lower.contains("sales") || lower.contains("business") ||
            lower.contains("revenue") || lower.contains("inventory")) {
            return CommandIntent(
                category = IntentCategory.ORDER_ANALYTICS,
                detectedLanguage = language,
                rawPrompt = rawCommand,
                summary = "E-Commerce daily order & inventory analytics query.",
                targetEntities = mapOf("scope" to "today", "metric" to "orders_and_sales")
            )
        }

        // 5. App interaction intent
        if (lower.contains("open") || lower.contains("launch") || lower.contains("whatsapp") || lower.contains("app")) {
            return CommandIntent(
                category = IntentCategory.APP_AUTOMATION,
                detectedLanguage = language,
                rawPrompt = rawCommand,
                summary = "App capability discovery & intent launch directive."
            )
        }

        // 6. Diagnostics
        if (lower.contains("status") || lower.contains("diagnostic") || lower.contains("telemetry") || lower.contains("health")) {
            return CommandIntent(
                category = IntentCategory.SYSTEM_DIAGNOSTICS,
                detectedLanguage = language,
                rawPrompt = rawCommand,
                summary = "System status & telemetry verification."
            )
        }

        // 7. General query
        return CommandIntent(
            category = IntentCategory.GENERAL_QUERY,
            detectedLanguage = language,
            rawPrompt = rawCommand,
            summary = "General operator directive."
        )
    }

    fun buildExecutionPlan(intent: CommandIntent): ExecutionPlan {
        val taskId = "TSK-${UUID.randomUUID().toString().take(6).uppercase()}"
        val actionList = mutableListOf<PlannedAction>()

        when (intent.category) {
            IntentCategory.SECURITY_PROHIBITED -> {
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Attempted credential / security access",
                        riskLevel = RiskLevel.L4,
                        targetModule = "SecurityGate",
                        payloadSummary = "Blocked: Operator prohibited from reading or handling passwords/OTPs."
                    )
                )
            }

            IntentCategory.PRODUCT_CAMPAIGN -> {
                // Canonical flow: USER COMMAND -> UNDERSTANDING -> PLANNING -> SECURITY CHECK -> APPROVAL -> EXECUTION -> REPORT
                // Step 1 (L1): Image intake & attribute parsing
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Inspect product image & attributes",
                        riskLevel = RiskLevel.L1,
                        targetModule = "ProductStudio",
                        payloadSummary = "Analyze visible attributes; stage required fields (price, sizes, stock count)."
                    )
                )
                // Step 2 (L1): Copywriting & layout formatting
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Generate marketing captions & hashtag set",
                        riskLevel = RiskLevel.L1,
                        targetModule = "SocialMediaOperator",
                        payloadSummary = "Draft multilingual captions in ${intent.detectedLanguage.displayName} and prepare 1:1 / 9:16 post assets."
                    )
                )
                // Step 3 (L2): Publication approval gate
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Publish product campaign to connected business channels",
                        riskLevel = RiskLevel.L2,
                        targetModule = "SocialMediaOperator",
                        payloadSummary = "Requires explicit operator approval before publishing externally to social media accounts."
                    )
                )
                // Step 4 (L0): Verify publication
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Verify publication URL & confirm ledger entry",
                        riskLevel = RiskLevel.L0,
                        targetModule = "AuditLedger",
                        payloadSummary = "Audit and confirm verified live status."
                    )
                )
            }

            IntentCategory.ORDER_ANALYTICS -> {
                // Step 1 (L0): Read order database
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Query local e-commerce order ledger",
                        riskLevel = RiskLevel.L0,
                        targetModule = "ECommerceEngine",
                        payloadSummary = "Fetch today's completed, pending, and shipped orders from local database."
                    )
                )
                // Step 2 (L0): Calculate analytics
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Calculate revenue & inventory metrics",
                        riskLevel = RiskLevel.L0,
                        targetModule = "MarketingIntelligence",
                        payloadSummary = "Compute total sales, average order value, and stock alert thresholds."
                    )
                )
                // Step 3 (L0): Generate executive report
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Compile daily business executive report",
                        riskLevel = RiskLevel.L0,
                        targetModule = "OperatorDashboard",
                        payloadSummary = "Render visual summary without fabricating missing metrics."
                    )
                )
            }

            IntentCategory.APP_AUTOMATION -> {
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Verify target application availability via Android Intent Broker",
                        riskLevel = RiskLevel.L0,
                        targetModule = "IntentBroker",
                        payloadSummary = "Check package manager for supported intent endpoints."
                    )
                )
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Launch user-approved application flow",
                        riskLevel = RiskLevel.L2,
                        targetModule = "UniversalMobileOperator",
                        payloadSummary = "Launch target application with user confirmation."
                    )
                )
            }

            IntentCategory.SYSTEM_DIAGNOSTICS, IntentCategory.GENERAL_QUERY -> {
                actionList.add(
                    PlannedAction(
                        taskId = taskId,
                        title = "Execute operator status diagnostics",
                        riskLevel = RiskLevel.L0,
                        targetModule = "TelemetryBus",
                        payloadSummary = "Inspect core frequency, quantum link, and memory buffers."
                    )
                )
            }
        }

        // Determine highest risk level
        val highestRisk = actionList.maxByOrNull { it.riskLevel.ordinal }?.riskLevel ?: RiskLevel.L0
        val requiresApproval = actionList.any { it.riskLevel.requiresApproval }

        return ExecutionPlan(
            userPrompt = intent.rawPrompt,
            intent = intent,
            actions = actionList,
            requiresApproval = requiresApproval,
            highestRiskLevel = highestRisk
        )
    }
}
