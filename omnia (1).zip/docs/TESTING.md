# OMNIA — Testing & Verification Guide

## 1. Automated Test Execution

### A. Android Test Suite
Runs unit and Robolectric tests validating state transitions, DataStore persistence, security gate enforcement, and multilingual intent classification:
```bash
gradle :app:testDebugUnitTest
```

### B. Python Backend Test Suite
Runs standard library tests verifying FastAPI logic, L4 prohibition blocking, task approval/cancellation, and cryptographic audit hashing:
```bash
python3 -m unittest backend/tests/test_backend.py
```

---

## 2. Test Coverage Matrix

| Test Suite | File | Focus Areas | Status |
|---|---|---|---|
| **Android Security & Planning** | `MasterVerificationTest.kt` | L4 blocking, L2 approval, Bangla/Banglish intent decomposition, Memory DB password filtering, E-Commerce calculations | **PASS (8/8)** |
| **Android State Machine** | `StateMachineTest.kt` | Valid 6-state transitions, illegal transition rejection, auto-demo cycling, core reset | **PASS (7/7)** |
| **Android Persistence** | `PersistenceTest.kt` | DataStore settings read/write, density clamping, haptic toggle | **PASS (4/4)** |
| **Android Robolectric** | `ExampleRobolectricTest.kt` | Context string lookup, AndroidViewModelFactory instantiation | **PASS (2/2)** |
| **Backend Endpoints & Logic** | `test_backend.py` | Health check, system status, campaign decomposition, L4 safety gate, task approval, audit signatures | **PASS (8/8)** |
