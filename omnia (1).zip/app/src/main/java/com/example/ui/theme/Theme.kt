package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val OmniaDarkColorScheme = darkColorScheme(
    primary = OmniaCyanPrimary,
    onPrimary = OmniaVoidBlack,
    primaryContainer = OmniaSurfaceElevated,
    onPrimaryContainer = OmniaCyanGlow,
    secondary = OmniaEmerald,
    onSecondary = OmniaVoidBlack,
    secondaryContainer = OmniaSurfaceVariant,
    onSecondaryContainer = OmniaEmerald,
    tertiary = OmniaNeonBlue,
    onTertiary = OmniaTextPrimary,
    background = OmniaVoidBlack,
    onBackground = OmniaTextPrimary,
    surface = OmniaSurface,
    onSurface = OmniaTextPrimary,
    surfaceVariant = OmniaSurfaceVariant,
    onSurfaceVariant = OmniaTextSecondary,
    outline = OmniaBorder,
    outlineVariant = OmniaBorderBright,
    error = OmniaCrimson,
    onError = OmniaTextPrimary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // Keep app consistently in premium dark sci-fi theme as specified
    MaterialTheme(
        colorScheme = OmniaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
