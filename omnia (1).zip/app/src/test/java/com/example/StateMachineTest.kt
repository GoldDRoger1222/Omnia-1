package com.example

import com.example.omnia.model.OperatorState
import com.example.omnia.state.OperatorStateMachine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class StateMachineTest {

    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)
    private lateinit var stateMachine: OperatorStateMachine

    @Before
    fun setUp() {
        stateMachine = OperatorStateMachine(testScope)
    }

    @Test
    fun initialState_isIdle() {
        assertEquals(OperatorState.IDLE, stateMachine.currentState.value)
    }

    @Test
    fun validLifecycleTransitionSequence_succeeds() {
        // IDLE -> LISTENING
        val step1 = stateMachine.transitionTo(OperatorState.LISTENING, "Voice trigger")
        assertTrue(step1)
        assertEquals(OperatorState.LISTENING, stateMachine.currentState.value)

        // LISTENING -> THINKING
        val step2 = stateMachine.transitionTo(OperatorState.THINKING, "Audio processed")
        assertTrue(step2)
        assertEquals(OperatorState.THINKING, stateMachine.currentState.value)

        // THINKING -> EXECUTING
        val step3 = stateMachine.transitionTo(OperatorState.EXECUTING, "Intent formulated")
        assertTrue(step3)
        assertEquals(OperatorState.EXECUTING, stateMachine.currentState.value)

        // EXECUTING -> SPEAKING
        val step4 = stateMachine.transitionTo(OperatorState.SPEAKING, "Reporting status")
        assertTrue(step4)
        assertEquals(OperatorState.SPEAKING, stateMachine.currentState.value)

        // SPEAKING -> IDLE
        val step5 = stateMachine.transitionTo(OperatorState.IDLE, "Voice broadcast done")
        assertTrue(step5)
        assertEquals(OperatorState.IDLE, stateMachine.currentState.value)
    }

    @Test
    fun illegalTransitionWithoutForce_isRejected() {
        // IDLE cannot directly transition to SPEAKING without listening/thinking
        val result = stateMachine.transitionTo(OperatorState.SPEAKING, "Direct jump", force = false)
        assertFalse(result)
        assertEquals(OperatorState.IDLE, stateMachine.currentState.value)
    }

    @Test
    fun forceTransition_overridesRulesForDeveloperDemo() {
        // Force transition from IDLE directly to SPEAKING
        val result = stateMachine.transitionTo(OperatorState.SPEAKING, "Developer override", force = true)
        assertTrue(result)
        assertEquals(OperatorState.SPEAKING, stateMachine.currentState.value)
    }

    @Test
    fun transitionToError_isAllowedFromAnyState() {
        stateMachine.transitionTo(OperatorState.LISTENING, "Voice buffer")
        val errorResult = stateMachine.transitionTo(OperatorState.ERROR, "Anomaly detected")
        assertTrue(errorResult)
        assertEquals(OperatorState.ERROR, stateMachine.currentState.value)
    }

    @Test
    fun resetToIdle_restoresIdleStateFromAnyState() {
        stateMachine.transitionTo(OperatorState.ERROR, "Crash test", force = true)
        stateMachine.resetToIdle("System recovery")
        assertEquals(OperatorState.IDLE, stateMachine.currentState.value)
        assertFalse(stateMachine.isAutoDemoRunning.value)
    }

    @Test
    fun activityLogs_recordAllEvents() {
        val initialCount = stateMachine.activityLogs.value.size
        stateMachine.transitionTo(OperatorState.LISTENING, "Step 1")
        stateMachine.transitionTo(OperatorState.THINKING, "Step 2")

        val newCount = stateMachine.activityLogs.value.size
        assertEquals(initialCount + 2, newCount)
        assertEquals(OperatorState.THINKING, stateMachine.activityLogs.value.first().state)
    }
}
