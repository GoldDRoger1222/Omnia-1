package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.omnia.app.ai.DeterministicOfflineFallbackProvider
import com.omnia.app.ai.HybridModelRouter
import com.omnia.app.ai.LocalOnDeviceAiProvider
import com.omnia.app.automation.OmniaAutomationDriver
import com.omnia.app.brain.IntentCategory
import com.omnia.app.brain.OmniaPlanner
import com.omnia.app.business.ECommerceEngine
import com.omnia.app.business.OrderStatus
import com.omnia.app.core.OmniaLanguage
import com.omnia.app.memory.MemoryRecord
import com.omnia.app.memory.OmniaMemoryDatabase
import com.omnia.app.security.ActionExecutionStatus
import com.omnia.app.security.ActionEvaluationResult
import com.omnia.app.security.PlannedAction
import com.omnia.app.security.RiskLevel
import com.omnia.app.security.SecurityGate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MasterVerificationTest {

    private lateinit var context: Context
    private lateinit var securityGate: SecurityGate
    private lateinit var planner: OmniaPlanner
    private lateinit var memoryDatabase: OmniaMemoryDatabase
    private lateinit var eCommerceEngine: ECommerceEngine
    private lateinit var automationDriver: OmniaAutomationDriver

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        securityGate = SecurityGate()
        val router = HybridModelRouter(LocalOnDeviceAiProvider())
        planner = OmniaPlanner(securityGate, router)
        memoryDatabase = OmniaMemoryDatabase(context)
        eCommerceEngine = ECommerceEngine()
        automationDriver = OmniaAutomationDriver(context)
    }

    @Test
    fun securityGate_blocksProhibitedL4Action() {
        val prohibitedAction = PlannedAction(
            taskId = "TSK-TEST",
            title = "Read user password from memory",
            riskLevel = RiskLevel.L4,
            targetModule = "SecurityGate",
            payloadSummary = "Prohibited test"
        )
        val result = securityGate.evaluateAction(prohibitedAction)
        assertTrue(result is ActionEvaluationResult.Blocked)
        assertEquals(ActionExecutionStatus.PROHIBITED_BLOCKED, prohibitedAction.status)
    }

    @Test
    fun securityGate_requiresApprovalForL2AndL3() {
        val l2Action = PlannedAction(
            taskId = "TSK-TEST-L2",
            title = "Broadcast post to Facebook",
            riskLevel = RiskLevel.L2,
            targetModule = "SocialMediaOperator",
            payloadSummary = "Publish post"
        )
        val result = securityGate.evaluateAction(l2Action)
        assertTrue(result is ActionEvaluationResult.RequiresApproval)
        assertEquals(ActionExecutionStatus.AWAITING_APPROVAL, l2Action.status)

        // Approve it explicitly
        val approved = securityGate.approveAction(l2Action)
        assertTrue(approved)
        assertEquals(ActionExecutionStatus.APPROVED, l2Action.status)
    }

    @Test
    fun planner_correctlyDecomposesDressCampaignDirective() {
        // Canonical Directive 1: "OMNIA, ei dress er product campaign ready kor"
        val prompt = "OMNIA, ei dress er product campaign ready kor"
        val intent = planner.interpretCommand(prompt)

        assertEquals(IntentCategory.PRODUCT_CAMPAIGN, intent.category)
        assertEquals(OmniaLanguage.BANGLISH, intent.detectedLanguage)

        val plan = planner.buildExecutionPlan(intent)
        assertTrue(plan.requiresApproval)
        assertEquals(RiskLevel.L2, plan.highestRiskLevel)
        assertEquals(4, plan.actions.size)
    }

    @Test
    fun planner_correctlyDecomposesOrderAnalyticsDirective() {
        // Canonical Directive 2: "OMNIA, amar business er ajker order gula analyze kor"
        val prompt = "OMNIA, amar business er ajker order gula analyze kor"
        val intent = planner.interpretCommand(prompt)

        assertEquals(IntentCategory.ORDER_ANALYTICS, intent.category)
        assertEquals(OmniaLanguage.BANGLISH, intent.detectedLanguage)

        val plan = planner.buildExecutionPlan(intent)
        assertFalse(plan.requiresApproval)
        assertEquals(RiskLevel.L0, plan.highestRiskLevel)
    }

    @Test
    fun memoryDatabase_rejectsPasswordsAndPerformsSearch() {
        // Test password rejection
        val badRecord = MemoryRecord(
            category = "SENSITIVE",
            key = "user_account_password",
            value = "super_secret_123"
        )
        val savedBad = memoryDatabase.saveRecord(badRecord)
        assertFalse(savedBad)

        // Test normal record save and search
        val goodRecord = MemoryRecord(
            category = "BUSINESS",
            key = "preferred_courier",
            value = "Steadfast Courier Banani Hub"
        )
        val savedGood = memoryDatabase.saveRecord(goodRecord)
        assertTrue(savedGood)

        val searchResults = memoryDatabase.searchRecords("Steadfast")
        assertTrue(searchResults.isNotEmpty())
        assertEquals("preferred_courier", searchResults[0].key)
    }

    @Test
    fun eCommerceEngine_tracksOrdersAndCalculatesDailyReport() {
        val orders = eCommerceEngine.getOrders()
        assertTrue(orders.isNotEmpty())

        val report = eCommerceEngine.calculateDailyReport()
        assertTrue(report.contains("Total Revenue: ৳"))
        assertTrue(report.contains("Total Orders:"))

        val initialStatus = orders[0].status
        val updated = eCommerceEngine.updateOrderStatus(orders[0].orderId, OrderStatus.DELIVERED)
        assertTrue(updated)
        assertEquals(OrderStatus.DELIVERED, eCommerceEngine.getOrders()[0].status)
    }

    @Test
    fun automationDriver_discoversSupportedApps() {
        val apps = automationDriver.discoverSupportedApps()
        assertTrue(apps.isNotEmpty())
        val packages = apps.map { it.packageName }
        assertTrue(packages.contains("com.whatsapp"))
        assertTrue(packages.contains("com.facebook.katana"))
    }

    @Test
    fun securityGate_ledgerHashChainingAndTamperDetection() {
        val gate = SecurityGate()

        val action1 = PlannedAction(
            taskId = "TSK-01",
            title = "Analyze catalog data",
            riskLevel = RiskLevel.L0,
            targetModule = "Analytics",
            payloadSummary = "Read-only analytics"
        )
        gate.evaluateAction(action1)

        val action2 = PlannedAction(
            taskId = "TSK-02",
            title = "Publish promotion",
            riskLevel = RiskLevel.L2,
            targetModule = "Social",
            payloadSummary = "Post promotion"
        )
        gate.evaluateAction(action2)
        gate.approveAction(action2)

        // Verify that the hash chain is cryptographically intact
        assertTrue(gate.verifyLedgerIntegrity())

        val ledger = gate.getAuditLedger()
        assertEquals(3, ledger.size) // 1 evaluate action1, 1 evaluate action2, 1 approve action2

        // Every hash must be a 64-char lowercase hex string (SHA-256)
        for (record in ledger) {
            assertEquals(64, record.cryptographicHash.length)
            assertEquals(64, record.previousHash.length)
        }
    }

    @Test
    fun productStudio_removesBackgroundAndRendersLayoutOnRealBitmap() {
        val engine = com.omnia.app.business.ProductStudioEngine()
        // Create a 200x200 bitmap with white background and a red square in the center using setPixel
        val source = android.graphics.Bitmap.createBitmap(200, 200, android.graphics.Bitmap.Config.ARGB_8888)
        for (x in 0 until 200) {
            for (y in 0 until 200) {
                if (x in 50..150 && y in 50..150) {
                    source.setPixel(x, y, android.graphics.Color.RED)
                } else {
                    source.setPixel(x, y, android.graphics.Color.WHITE)
                }
            }
        }

        // Process chroma removal
        val transparent = engine.removeBackgroundChroma(source)
        // Check that a corner pixel (formerly white) is now transparent
        val cornerAlpha = android.graphics.Color.alpha(transparent.getPixel(10, 10))
        assertEquals(0, cornerAlpha)

        // Check that center pixel (red) retained full opacity
        val centerAlpha = android.graphics.Color.alpha(transparent.getPixel(100, 100))
        assertEquals(255, centerAlpha)

        // Render full marketing layout (Square 1080x1080)
        val layout = engine.renderLayout(
            sourceBitmap = transparent,
            format = com.omnia.app.business.ProductLayoutFormat.SQUARE_POST,
            title = "PREMIUM SILK SAREE",
            priceText = "৳ 4,500"
        )
        assertEquals(1080, layout.width)
        assertEquals(1080, layout.height)
    }

    @Test
    fun courierAdapters_produceValidTrackingAndWaybills() = kotlinx.coroutines.runBlocking {
        val steadfast = com.omnia.app.business.SteadfastCourierAdapter()
        assertTrue(steadfast.isSandboxMode)
        val trackingResult = steadfast.trackConsignment("STF-889922")
        assertTrue(trackingResult.isSuccess)
        val tracking = trackingResult.getOrNull()!!
        assertTrue(tracking.status.contains("IN_TRANSIT"))
        assertEquals("Dhaka Central Sorting Hub", tracking.currentHub)

        val pathao = com.omnia.app.business.PathaoCourierAdapter()
        val pathaoTracking = pathao.trackConsignment("PTH-109283").getOrNull()!!
        assertEquals("PROCESSING_AT_HUB", pathaoTracking.status)

        val redx = com.omnia.app.business.RedXCourierAdapter()
        val redxTracking = redx.trackConsignment("REDX-776655").getOrNull()!!
        assertEquals("PICKED_UP", redxTracking.status)
    }
}
