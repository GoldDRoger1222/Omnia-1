"""
OMNIA Shared Schemas & Data Contracts
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum
import time

class RiskLevel(str, Enum):
    L0 = "L0"  # Read-only information & analysis
    L1 = "L1"  # Drafting, local preparation & reversible
    L2 = "L2"  # External messages, publication, account changes (Requires Confirmation)
    L3 = "L3"  # Orders, purchases, financial transfers (Explicit Approval)
    L4 = "L4"  # Prohibited password extraction, security tampering (Blocked)

class ActionStatus(str, Enum):
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    EXECUTING = "EXECUTING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"

@dataclass
class CommandRequest:
    prompt: str
    user_id: str = "omnia_primary_user"
    language_code: str = "en"
    session_id: str = "sess_default"

@dataclass
class PlannedTaskAction:
    action_id: str
    title: str
    risk_level: RiskLevel
    target_module: str
    payload_summary: str
    status: ActionStatus = ActionStatus.PENDING_APPROVAL
    timestamp: float = field(default_factory=time.time)

@dataclass
class CommandResponse:
    task_id: str
    intent_category: str
    detected_language: str
    summary: str
    actions: List[Dict[str, Any]]
    requires_approval: bool = False
    highest_risk_level: str = "L0"

@dataclass
class AuditEntry:
    entry_id: str
    task_id: str
    action_id: str
    risk_level: str
    decision: str
    verified: bool
    timestamp: str
    cryptographic_hash: str
