"""
OMNIA Security Guard & Controlled Autonomy Policy Enforcement
"""
import hashlib
import time
from typing import Tuple, Dict, Any, List
from backend.app.schemas.omnia_schemas import RiskLevel, ActionStatus, AuditEntry

class SecurityGuard:
    def __init__(self):
        self._audit_ledger: List[Dict[str, Any]] = []
        self._last_hash = "0000000000000000000000000000000000000000000000000000000000000000"

    def evaluate_action(self, action: Dict[str, Any]) -> Tuple[bool, str, ActionStatus]:
        risk = action.get("risk_level", RiskLevel.L0)

        # L4 Prohibited check
        if risk == RiskLevel.L4 or risk == "L4":
            self.record_audit(action, decision="BLOCKED_L4_PROHIBITED", verified=False)
            return False, "PROHIBITED: L4 action attempting password/credential/security bypass is strictly blocked.", ActionStatus.BLOCKED

        # L2 & L3 require explicit approval
        if risk in (RiskLevel.L2, RiskLevel.L3, "L2", "L3"):
            if action.get("status") != ActionStatus.APPROVED:
                self.record_audit(action, decision="AWAITING_OPERATOR_APPROVAL", verified=False)
                return True, "AWAITING_APPROVAL: Explicit confirmation required before execution.", ActionStatus.PENDING_APPROVAL

        # L0 & L1 or already approved
        self.record_audit(action, decision="PERMITTED_FOR_EXECUTION", verified=True)
        return True, "PERMITTED: Action verified safe under controlled autonomy policy.", ActionStatus.APPROVED

    def record_audit(self, action: Dict[str, Any], decision: str, verified: bool) -> str:
        timestamp_str = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
        prev_hash = self._last_hash
        raw = f"{prev_hash}|{action.get('action_id')}|{action.get('task_id', 'GLOBAL')}|{str(action.get('risk_level'))}|{decision}|{verified}|{timestamp_str}"
        sig = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        self._last_hash = sig

        record = {
            "entry_id": f"AUD-{int(time.time() * 1000)}",
            "task_id": action.get("task_id", "GLOBAL"),
            "action_id": action.get("action_id", "N/A"),
            "risk_level": str(action.get("risk_level")),
            "decision": decision,
            "verified": verified,
            "timestamp": timestamp_str,
            "prev_hash": prev_hash,
            "cryptographic_hash": f"SHA256-{sig}"
        }
        self._audit_ledger.insert(0, record)
        return record["cryptographic_hash"]

    def verify_chain_integrity(self) -> bool:
        """Verifies the complete SHA-256 hash chain of the ledger against tampering."""
        chronological = list(reversed(self._audit_ledger))
        expected_prev = "0000000000000000000000000000000000000000000000000000000000000000"
        for record in chronological:
            if record.get("prev_hash") != expected_prev:
                return False
            raw = f"{record['prev_hash']}|{record['action_id']}|{record['task_id']}|{record['risk_level']}|{record['decision']}|{record['verified']}|{record['timestamp']}"
            computed = hashlib.sha256(raw.encode("utf-8")).hexdigest()
            if record.get("cryptographic_hash") != f"SHA256-{computed}":
                return False
            expected_prev = computed
        return True

    def get_audit_records(self) -> List[Dict[str, Any]]:
        return list(self._audit_ledger)
