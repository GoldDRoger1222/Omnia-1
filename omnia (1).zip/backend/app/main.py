"""
OMNIA Universal AI Mobile Operator — FastAPI Backend Application
"""
import sys
import os
import json
import time
from typing import Dict, Any, List

# Ensure package import resolution
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from backend.app.config import settings
from backend.app.security.security_guard import SecurityGuard
from backend.app.planner.task_planner import BackendTaskPlanner

security_guard = SecurityGuard()
planner = BackendTaskPlanner()

# In-memory store for tasks and integrations
tasks_store: Dict[str, Dict[str, Any]] = {}

def get_health() -> Dict[str, Any]:
    return {
        "status": "HEALTHY",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "timestamp": time.time()
    }

def get_system_status() -> Dict[str, Any]:
    return {
        "neural_engine": "NOMINAL (99.8%)",
        "active_mesh": "L1-MESH QUANTUM LINK",
        "controlled_autonomy": "STRICT_ENFORCEMENT",
        "active_tasks_count": len(tasks_store),
        "audit_records_count": len(security_guard.get_audit_records())
    }

def process_command(prompt: str, user_id: str = "omnia_user") -> Dict[str, Any]:
    plan = planner.interpret_and_plan(prompt)
    tasks_store[plan["task_id"]] = plan

    # Evaluate actions through security gate
    for action in plan["actions"]:
        permitted, reason, status = security_guard.evaluate_action(action)
        action["status"] = status.value
        action["policy_reason"] = reason

    return plan

def approve_task(task_id: str) -> Dict[str, Any]:
    task = tasks_store.get(task_id)
    if not task:
        return {"error": "TASK_NOT_FOUND", "task_id": task_id}

    for action in task["actions"]:
        if action["risk_level"] != "L4":
            action["status"] = "APPROVED"
            security_guard.record_audit(action, decision="USER_EXPLICIT_APPROVAL_GRANTED", verified=True)

    task["requires_approval"] = False
    return {"status": "SUCCESS", "task_id": task_id, "actions": task["actions"]}

def cancel_task(task_id: str) -> Dict[str, Any]:
    task = tasks_store.get(task_id)
    if not task:
        return {"error": "TASK_NOT_FOUND", "task_id": task_id}

    for action in task["actions"]:
        action["status"] = "REJECTED"
        security_guard.record_audit(action, decision="USER_TASK_CANCELLED", verified=True)

    return {"status": "CANCELLED", "task_id": task_id}

def get_providers() -> List[Dict[str, Any]]:
    return [
        {
            "id": "gemini_online",
            "name": "Gemini 1.5/2.0 (Online Provider)",
            "type": "ONLINE_CLOUD",
            "status": "AWAITING_CONFIG",
            "requires_key": True
        },
        {
            "id": "local_slm",
            "name": "OMNIA Local SLM (On-Device Inference)",
            "type": "LOCAL_ON_DEVICE",
            "status": "HEALTHY",
            "requires_key": False
        },
        {
            "id": "rule_core",
            "name": "Deterministic Fallback Engine",
            "type": "OFFLINE_FALLBACK",
            "status": "HEALTHY",
            "requires_key": False
        }
    ]

def get_integrations() -> List[Dict[str, Any]]:
    return [
        {"package": "com.whatsapp", "name": "WhatsApp", "status": "INTENT_AVAILABLE"},
        {"package": "com.facebook.katana", "name": "Facebook", "status": "INTENT_AVAILABLE"},
        {"package": "com.instagram.android", "name": "Instagram", "status": "INTENT_AVAILABLE"},
        {"package": "com.android.chrome", "name": "Google Chrome", "status": "INTENT_AVAILABLE"},
        {"package": "com.google.android.apps.photos", "name": "Google Photos", "status": "INTENT_AVAILABLE"}
    ]

def get_audit() -> List[Dict[str, Any]]:
    return security_guard.get_audit_records()

# Try initializing FastAPI if installed
try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel

    app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    class CommandInput(BaseModel):
        prompt: str
        user_id: str = "omnia_user"

    @app.get("/api/v1/health")
    async def api_health():
        return get_health()

    @app.get("/api/v1/status")
    async def api_status():
        return get_system_status()

    @app.post("/api/v1/commands")
    async def api_commands(cmd: CommandInput):
        return process_command(cmd.prompt, cmd.user_id)

    @app.get("/api/v1/tasks")
    async def api_get_tasks():
        return list(tasks_store.values())

    @app.get("/api/v1/tasks/{task_id}")
    async def api_get_task(task_id: str):
        task = tasks_store.get(task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        return task

    @app.post("/api/v1/tasks/{task_id}/approve")
    async def api_approve_task(task_id: str):
        res = approve_task(task_id)
        if "error" in res:
            raise HTTPException(status_code=404, detail=res["error"])
        return res

    @app.post("/api/v1/tasks/{task_id}/cancel")
    async def api_cancel_task(task_id: str):
        res = cancel_task(task_id)
        if "error" in res:
            raise HTTPException(status_code=404, detail=res["error"])
        return res

    @app.get("/api/v1/providers")
    async def api_providers():
        return get_providers()

    @app.get("/api/v1/integrations")
    async def api_integrations():
        return get_integrations()

    @app.get("/api/v1/audit")
    async def api_audit():
        return get_audit()

    @app.websocket("/ws/omnia")
    async def websocket_endpoint(websocket: WebSocket):
        await websocket.accept()
        try:
            while True:
                data = await websocket.receive_text()
                response = {
                    "event": "ACK",
                    "echo": data,
                    "server_time": time.time()
                }
                await websocket.send_text(json.dumps(response))
        except WebSocketDisconnect:
            pass

except ImportError:
    app = None
