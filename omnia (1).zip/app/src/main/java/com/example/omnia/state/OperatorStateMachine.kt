package com.example.omnia.state

import com.example.omnia.model.ActivityLog
import com.example.omnia.model.OperatorState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * State machine orchestrating the operational states of the OMNIA Mobile Operator.
 * Guarantees valid transition flows, event logging, and provides developer demo cycling.
 */
class OperatorStateMachine(
    private val scope: CoroutineScope,
    initialState: OperatorState = OperatorState.IDLE
) {
    private val _currentState = MutableStateFlow(initialState)
    val currentState: StateFlow<OperatorState> = _currentState.asStateFlow()

    private val _activityLogs = MutableStateFlow<List<ActivityLog>>(
        listOf(
            createLog(OperatorState.IDLE, "OMNIA Universal Mobile Operator Core initialized. System Nominal.")
        )
    )
    val activityLogs: StateFlow<List<ActivityLog>> = _activityLogs.asStateFlow()

    private val _lastTransitionMessage = MutableStateFlow("Core standing by in IDLE mode.")
    val lastTransitionMessage: StateFlow<String> = _lastTransitionMessage.asStateFlow()

    private val _isAutoDemoRunning = MutableStateFlow(false)
    val isAutoDemoRunning: StateFlow<Boolean> = _isAutoDemoRunning.asStateFlow()

    private var autoCycleJob: Job? = null

    /**
     * Attempts to transition to a new state.
     * @param target The target state.
     * @param reason The trigger or reason for transition.
     * @param force If true, bypasses transition validation rules (useful for manual dev overrides).
     * @return Result of the transition attempt.
     */
    fun transitionTo(
        target: OperatorState,
        reason: String = "Manual operator command",
        force: Boolean = false
    ): Boolean {
        val current = _currentState.value
        if (current == target) {
            return true
        }

        if (!force && !current.canTransitionTo(target)) {
            val errMsg = "Transition rejected: ${current.name} -> ${target.name} is illegal in state flow."
            _lastTransitionMessage.value = errMsg
            addLog(
                state = current,
                message = "REJECTED: ${current.code} -> ${target.code} ($reason)",
                isAnomaly = true
            )
            return false
        }

        _currentState.value = target
        val logMsg = "Transitioned [${current.code} -> ${target.code}]: $reason"
        _lastTransitionMessage.value = logMsg
        addLog(
            state = target,
            message = logMsg,
            isAnomaly = (target == OperatorState.ERROR)
        )
        return true
    }

    /**
     * Resets the core to IDLE state.
     */
    fun resetToIdle(reason: String = "Operator system reset") {
        stopAutoCycle()
        _currentState.value = OperatorState.IDLE
        val msg = "System reset: Core restored to IDLE state ($reason)."
        _lastTransitionMessage.value = msg
        addLog(OperatorState.IDLE, msg)
    }

    /**
     * Toggles automatic developer demonstration cycling across all 6 core states.
     */
    fun toggleAutoDemo(cycleDelayMs: Long = 2800L) {
        if (_isAutoDemoRunning.value) {
            stopAutoCycle()
        } else {
            startAutoCycle(cycleDelayMs)
        }
    }

    private fun startAutoCycle(cycleDelayMs: Long) {
        autoCycleJob?.cancel()
        _isAutoDemoRunning.value = true
        addLog(OperatorState.IDLE, "Developer Auto-Cycle sequence engaged.")

        autoCycleJob = scope.launch {
            val sequence = listOf(
                OperatorState.IDLE,
                OperatorState.LISTENING,
                OperatorState.THINKING,
                OperatorState.EXECUTING,
                OperatorState.SPEAKING,
                OperatorState.ERROR,
                OperatorState.IDLE
            )

            var index = 0
            while (isActive) {
                delay(cycleDelayMs)
                index = (index + 1) % sequence.size
                val next = sequence[index]
                transitionTo(
                    target = next,
                    reason = "Dev Auto-Cycle sequence step #${index + 1}",
                    force = true
                )
            }
        }
    }

    fun stopAutoCycle() {
        autoCycleJob?.cancel()
        autoCycleJob = null
        _isAutoDemoRunning.value = false
    }

    private fun addLog(state: OperatorState, message: String, isAnomaly: Boolean = false) {
        val newLog = createLog(state, message, isAnomaly)
        val currentList = _activityLogs.value.toMutableList()
        currentList.add(0, newLog) // Prepend newest
        if (currentList.size > 50) {
            currentList.removeAt(currentList.lastIndex)
        }
        _activityLogs.value = currentList
    }

    private fun createLog(state: OperatorState, message: String, isAnomaly: Boolean = false): ActivityLog {
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
        return ActivityLog(
            id = UUID.randomUUID().toString(),
            timestamp = timeFormat.format(Date()),
            state = state,
            message = message,
            isAnomaly = isAnomaly
        )
    }
}
