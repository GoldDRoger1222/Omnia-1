package com.example

import android.content.Context
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.test.core.app.ApplicationProvider
import com.example.omnia.data.OmniaPreferencesRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PersistenceTest {

    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)
    private lateinit var repository: OmniaPreferencesRepository
    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        val testDataStore = PreferenceDataStoreFactory.create(
            scope = testScope,
            produceFile = { context.preferencesDataStoreFile("test_omnia_settings_${System.currentTimeMillis()}") }
        )
        repository = OmniaPreferencesRepository(testDataStore)
    }

    @Test
    fun defaultSettings_areCorrect() = testScope.runTest {
        val settings = repository.settingsFlow.first()
        assertTrue(settings.particlesEnabled)
        assertEquals(45, settings.particleDensity)
        assertEquals(1.0f, settings.corePulseSpeed)
        assertTrue(settings.hapticFeedbackEnabled)
        assertEquals("OMNIA-ALPHA-01", settings.operatorName)
    }

    @Test
    fun updateParticlesEnabled_persistsValue() = testScope.runTest {
        repository.updateParticlesEnabled(false)
        val settings = repository.settingsFlow.first()
        assertFalse(settings.particlesEnabled)
    }

    @Test
    fun updateParticleDensity_clampsWithinBounds() = testScope.runTest {
        repository.updateParticleDensity(60)
        val settings = repository.settingsFlow.first()
        assertEquals(60, settings.particleDensity)

        // Test lower bound clamping (min 10)
        repository.updateParticleDensity(2)
        val lowerClamped = repository.settingsFlow.first()
        assertEquals(10, lowerClamped.particleDensity)
    }

    @Test
    fun updateOperatorName_persistsCorrectly() = testScope.runTest {
        repository.updateOperatorName("OMNIA-COMMANDER-X")
        val settings = repository.settingsFlow.first()
        assertEquals("OMNIA-COMMANDER-X", settings.operatorName)
    }
}
