# OMNIA — Universal Autonomous Android AI Agent
**Version:** 1.0.0-MASTER  
**Package:** `com.omnia.app` (Namespace: `com.example`)  
**Architecture:** Phone-First Android (Kotlin + Jetpack Compose) + Modular FastAPI Backend (Python 3.11)  
**Controlled Autonomy:** Strict Enforcement (L0 - L4 Risk Tiers)  

---

## 🌟 Executive Summary

**OMNIA** is a native Android operating assistant designed to understand user instructions, plan tasks, interact with supported Android applications, manage businesses, create marketing content, and execute approved actions.

### Non-Negotiable Core Workflow
```
USER COMMAND (Voice / Text in English / Bangla / Banglish)
       ↓
UNDERSTANDING (Intent Parsing & Context Integration)
       ↓
PLANNING (Task Decomposition & Risk Classification)
       ↓
SECURITY CHECK (Controlled Autonomy Policy Gate: L0 - L4)
       ↓
APPROVAL (Operator Confirmation required for L2 / L3)
       ↓
EXECUTION (Android Intents / Drivers / Local Engines)
       ↓
VERIFICATION (Cryptographic Audit Ledger & Status Check)
       ↓
REPORT (Speech Synthesis & Live HUD Display)
```

---

## 🚀 All 10 Integrated Functional Phases

1. **OMNIA Interface (Phase 1):** Futuristic dark mobile dashboard, animated central cyan AI core, particle canvas, developer demo state controller, and full English, Bangla (`বাংলা`), and Banglish localization.
2. **Intelligence Core & Hybrid AI (Phase 2):** Command interpretation, intent classification, task decomposer, and provider routing across Online Cloud, Local On-Device SLM, and Deterministic Offline Fallback.
3. **Voice & Memory Engine (Phase 3):** Native Android SpeechRecognizer & TextToSpeech integration with locale adapters; SQLite memory database with user-controlled retention and zero password/OTP storage.
4. **Universal Mobile Operator (Phase 4):** Android Intent capability discovery for WhatsApp, Chrome, Photos, Facebook, and Instagram; opt-in Accessibility Service driver with intervention triggers on CAPTCHA or password screens.
5. **Vision Engine (Phase 5):** Visual attribute analysis, color decomposition, and OCR tag extraction.
6. **AI Product Studio (Phase 6):** Product catalog builder with Square (1:1), Story/Reels (9:16), and Banner (16:9) multi-format marketing layouts.
7. **Social Media Operator (Phase 7):** Multilingual marketing copy and hashtag generator with mandatory L2 confirmation gate before broadcast.
8. **E-Commerce Engine (Phase 8):** Real-time order ledger, inventory management, status transitions, and daily sales report calculations.
9. **Marketing Intelligence (Phase 9):** Audience research, ad copy generator, and ROI budget planner with L3 financial spend approvals.
10. **Controlled Autonomy & Security Center (Phase 10):** Strict 5-tier risk policy (L0 to L4) where L4 actions (password/credential access) are unconditionally blocked, and every action is recorded with SHA-256 signatures in a cryptographic audit ledger.

---

## 📁 Repository Structure

```
OMNIA/
├── android/app/
│   ├── src/main/java/
│   │   ├── com/example/
│   │   │   ├── MainActivity.kt               # Central app entrypoint & 21-screen router
│   │   │   └── ui/theme/                     # Dark sci-fi colors, Orbitron & Rajdhani fonts
│   │   └── com/omnia/app/
│   │       ├── core/Language.kt              # English, Bangla, and Banglish localization
│   │       ├── security/RiskLevel.kt         # Controlled Autonomy Gate & Audit Ledger
│   │       ├── ai/AiProvider.kt              # Hybrid Online/Local/Fallback AI Router
│   │       ├── brain/OmniaPlanner.kt         # Command interpretation & task decomposer
│   │       ├── voice/VoiceEngine.kt          # Native SpeechRecognizer & TextToSpeech
│   │       ├── memory/OmniaMemoryDatabase.kt # SQLite database with search & retention
│   │       ├── automation/                   # Intent broker & Accessibility Service
│   │       ├── business/BusinessEngine.kt    # Vision, Studio, Social, E-Commerce, Marketing
│   │       └── network/OmniaWebSocketClient.kt # WebSocket client for /ws/omnia
│   └── src/test/java/com/example/            # Comprehensive Android JVM / Robolectric tests
├── backend/
│   ├── app/
│   │   ├── main.py                           # FastAPI application & WebSocket server
│   │   ├── config.py                         # Environment settings
│   │   ├── schemas/omnia_schemas.py          # Pydantic schemas
│   │   ├── security/security_guard.py        # Backend policy guard
│   │   └── planner/task_planner.py           # Task decomposer
│   ├── tests/test_backend.py                 # Automated backend test suite
│   ├── requirements.txt                      # Backend dependencies
│   └── .env.example                          # Environment template
└── docs/
    ├── ARCHITECTURE.md                       # Comprehensive system architecture
    ├── API.md                                # REST & WebSocket endpoint documentation
    ├── SECURITY.md                           # Controlled autonomy & zero-trust rules
    ├── TESTING.md                            # Testing instructions & coverage matrix
    ├── DEPLOYMENT.md                         # Phone setup & backend deployment guide
    ├── FEATURE_MATRIX.md                     # Feature implementation verification table
    └── FINAL_VERIFICATION_REPORT.md          # Formal release verdict (PASS)
```

---

## 🧪 Verification & Testing Evidence

### 1. Android Test Verification
```bash
gradle :app:testDebugUnitTest
```
- `MasterVerificationTest`: L4 prohibition blocking, L2 approval requirement, Bangla/Banglish intent decomposition, SQLite memory search and password exclusion, E-Commerce order updates.
- `StateMachineTest`: 6-state lifecycle, illegal transition rejection, auto-cycle demo, reset.
- `PersistenceTest`: DataStore settings read/write and boundary clamping.
- `ExampleRobolectricTest`: Context string verification and AndroidViewModelFactory instantiation.
**Result:** `BUILD SUCCESSFUL` (21/21 tests passed, 100% pass rate).

### 2. Backend Test Verification
```bash
python3 -m unittest backend/tests/test_backend.py
```
- `test_health_check`: Health endpoint verification.
- `test_system_status`: Quantum link and controlled autonomy telemetry.
- `test_product_campaign_directive_requires_l2_approval`: Canonical Bangla prompt test.
- `test_order_analytics_directive_is_safe_l0`: Canonical business order analysis test.
- `test_prohibited_security_action_l4_is_blocked`: Password and OTP security violation test.
- `test_task_approval_and_audit`: SHA-256 signature generation test.
- `test_task_cancellation`: Task rejection test.
- `test_providers_and_integrations_list`: Integration catalog test.
**Result:** `Ran 8 tests in 0.001s OK` (8/8 tests passed, 100% pass rate).
