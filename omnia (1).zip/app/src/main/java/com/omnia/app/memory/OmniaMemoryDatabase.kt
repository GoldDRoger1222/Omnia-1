package com.omnia.app.memory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class MemoryRecord(
    val id: String = UUID.randomUUID().toString(),
    val businessId: String = "default_business",
    val category: String, // e.g. "PREFERENCE", "TASK_LOG", "PRODUCT", "CUSTOMER_NOTE"
    val key: String,
    val value: String,
    val timestamp: String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
    val isSensitive: Boolean = false
)

/**
 * Robust local SQLite Memory Database for OMNIA.
 * Provides user-controlled retention, keyword search, business isolation,
 * and strict filtering against password/OTP storage.
 */
class OmniaMemoryDatabase(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "omnia_memory.db"
        const val DATABASE_VERSION = 1

        const val TABLE_MEMORY = "memory_records"
        const val COL_ID = "id"
        const val COL_BUSINESS_ID = "business_id"
        const val COL_CATEGORY = "category"
        const val COL_KEY = "key_name"
        const val COL_VALUE = "value_content"
        const val COL_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createSql = """
            CREATE TABLE $TABLE_MEMORY (
                $COL_ID TEXT PRIMARY KEY,
                $COL_BUSINESS_ID TEXT NOT NULL,
                $COL_CATEGORY TEXT NOT NULL,
                $COL_KEY TEXT NOT NULL,
                $COL_VALUE TEXT NOT NULL,
                $COL_TIMESTAMP TEXT NOT NULL
            )
        """.trimIndent()
        db.execSQL(createSql)

        // Seed initial business memory node safely
        val initialValues = ContentValues().apply {
            put(COL_ID, UUID.randomUUID().toString())
            put(COL_BUSINESS_ID, "default_business")
            put(COL_CATEGORY, "SYSTEM")
            put(COL_KEY, "operator_mode")
            put(COL_VALUE, "CONTROLLED_AUTONOMY_ACTIVE")
            put(COL_TIMESTAMP, SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
        }
        db.insert(TABLE_MEMORY, null, initialValues)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MEMORY")
        onCreate(db)
    }

    fun saveRecord(record: MemoryRecord): Boolean {
        // Enforce rule: Never store passwords, OTPs, or financial secrets
        val lowerKey = record.key.lowercase()
        val lowerVal = record.value.lowercase()
        if (lowerKey.contains("password") || lowerKey.contains("otp") || lowerKey.contains("pin") ||
            lowerVal.contains("password") || lowerVal.contains("otp") || lowerVal.contains("cvv")) {
            return false // Refused by security rule
        }

        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_ID, record.id)
            put(COL_BUSINESS_ID, record.businessId)
            put(COL_CATEGORY, record.category)
            put(COL_KEY, record.key)
            put(COL_VALUE, record.value)
            put(COL_TIMESTAMP, record.timestamp)
        }
        val result = db.insertWithOnConflict(TABLE_MEMORY, null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return result != -1L
    }

    fun searchRecords(query: String, businessId: String = "default_business"): List<MemoryRecord> {
        val db = readableDatabase
        val list = mutableListOf<MemoryRecord>()
        val selection = "$COL_BUSINESS_ID = ? AND ($COL_KEY LIKE ? OR $COL_VALUE LIKE ?)"
        val args = arrayOf(businessId, "%$query%", "%$query%")

        db.query(TABLE_MEMORY, null, selection, args, null, null, "$COL_TIMESTAMP DESC").use { cursor ->
            val idIdx = cursor.getColumnIndexOrThrow(COL_ID)
            val bizIdx = cursor.getColumnIndexOrThrow(COL_BUSINESS_ID)
            val catIdx = cursor.getColumnIndexOrThrow(COL_CATEGORY)
            val keyIdx = cursor.getColumnIndexOrThrow(COL_KEY)
            val valIdx = cursor.getColumnIndexOrThrow(COL_VALUE)
            val timeIdx = cursor.getColumnIndexOrThrow(COL_TIMESTAMP)

            while (cursor.moveToNext()) {
                list.add(
                    MemoryRecord(
                        id = cursor.getString(idIdx),
                        businessId = cursor.getString(bizIdx),
                        category = cursor.getString(catIdx),
                        key = cursor.getString(keyIdx),
                        value = cursor.getString(valIdx),
                        timestamp = cursor.getString(timeIdx)
                    )
                )
            }
        }
        return list
    }

    fun getAllRecords(businessId: String = "default_business"): List<MemoryRecord> {
        val db = readableDatabase
        val list = mutableListOf<MemoryRecord>()
        val selection = "$COL_BUSINESS_ID = ?"
        val args = arrayOf(businessId)

        db.query(TABLE_MEMORY, null, selection, args, null, null, "$COL_TIMESTAMP DESC").use { cursor ->
            val idIdx = cursor.getColumnIndexOrThrow(COL_ID)
            val bizIdx = cursor.getColumnIndexOrThrow(COL_BUSINESS_ID)
            val catIdx = cursor.getColumnIndexOrThrow(COL_CATEGORY)
            val keyIdx = cursor.getColumnIndexOrThrow(COL_KEY)
            val valIdx = cursor.getColumnIndexOrThrow(COL_VALUE)
            val timeIdx = cursor.getColumnIndexOrThrow(COL_TIMESTAMP)

            while (cursor.moveToNext()) {
                list.add(
                    MemoryRecord(
                        id = cursor.getString(idIdx),
                        businessId = cursor.getString(bizIdx),
                        category = cursor.getString(catIdx),
                        key = cursor.getString(keyIdx),
                        value = cursor.getString(valIdx),
                        timestamp = cursor.getString(timeIdx)
                    )
                )
            }
        }
        return list
    }

    fun deleteRecord(id: String): Boolean {
        val db = writableDatabase
        return db.delete(TABLE_MEMORY, "$COL_ID = ?", arrayOf(id)) > 0
    }

    fun clearAll(businessId: String = "default_business"): Boolean {
        val db = writableDatabase
        return db.delete(TABLE_MEMORY, "$COL_BUSINESS_ID = ?", arrayOf(businessId)) >= 0
    }
}
