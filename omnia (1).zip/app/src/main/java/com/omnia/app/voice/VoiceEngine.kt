package com.omnia.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import com.omnia.app.core.OmniaLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceState {
    STANDBY,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

/**
 * Native Android Voice Engine integrating SpeechRecognizer and TextToSpeech
 * with support for Bangla ("bn_BD") and English ("en_US") locales.
 */
class VoiceEngine(
    private val context: Context,
    private val onResult: (String) -> Unit = {}
) : RecognitionListener {

    private val _voiceState = MutableStateFlow(VoiceState.STANDBY)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsInitialized = true
                textToSpeech?.language = Locale.US
            }
        }
    }

    fun startListening(language: OmniaLanguage = OmniaLanguage.ENGLISH) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceState.value = VoiceState.ERROR
            return
        }

        stopSpeaking()
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(this@VoiceEngine)
        }

        val locale = when (language) {
            OmniaLanguage.BANGLA, OmniaLanguage.BANGLISH -> "bn-BD"
            OmniaLanguage.ENGLISH -> "en-US"
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "OMNIA is listening...")
        }

        try {
            speechRecognizer?.startListening(intent)
            _voiceState.value = VoiceState.LISTENING
        } catch (e: Exception) {
            _voiceState.value = VoiceState.ERROR
        }
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        if (_voiceState.value == VoiceState.LISTENING) {
            _voiceState.value = VoiceState.STANDBY
        }
    }

    fun speak(text: String, language: OmniaLanguage = OmniaLanguage.ENGLISH) {
        if (!isTtsInitialized || text.isBlank()) return

        val locale = when (language) {
            OmniaLanguage.BANGLA, OmniaLanguage.BANGLISH -> Locale("bn", "BD")
            OmniaLanguage.ENGLISH -> Locale.US
        }

        textToSpeech?.language = locale
        _lastSpokenText.value = text
        _voiceState.value = VoiceState.SPEAKING
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "omnia_tts_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        if (_voiceState.value == VoiceState.SPEAKING) {
            _voiceState.value = VoiceState.STANDBY
        }
    }

    fun destroy() {
        speechRecognizer?.destroy()
        textToSpeech?.shutdown()
    }

    // SpeechRecognizer Callbacks
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {
        _voiceState.value = VoiceState.LISTENING
    }
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {
        _voiceState.value = VoiceState.PROCESSING
    }
    override fun onError(error: Int) {
        _voiceState.value = VoiceState.STANDBY
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val bestMatch = matches?.firstOrNull() ?: ""
        _voiceState.value = VoiceState.STANDBY
        if (bestMatch.isNotBlank()) {
            onResult(bestMatch)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
