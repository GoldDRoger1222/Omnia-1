package com.example.omnia.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.omnia.model.TaskItem
import com.example.omnia.model.TaskStatus
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaAmber
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@Composable
fun TasksScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    var showAddTaskDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .testTag("tasks_screen")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TASK PIPELINE",
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaCyanPrimary,
                                fontSize = 22.sp
                            )
                        )
                        Text(
                            text = "OPERATOR EXECUTION QUEUE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                letterSpacing = 1.2.sp,
                                color = OmniaTextMuted
                            )
                        )
                    }

                    // Dispatch Task Button
                    Box(
                        modifier = Modifier
                            .testTag("btn_dispatch_task")
                            .clip(RoundedCornerShape(8.dp))
                            .background(OmniaSurfaceElevated)
                            .border(1.dp, OmniaCyanPrimary, RoundedCornerShape(8.dp))
                            .clickable { showAddTaskDialog = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Task",
                                tint = OmniaCyanPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "SCHEDULE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = OrbitronFamily,
                                    color = OmniaCyanPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            // Task statistics summary
            item {
                TaskQueueSummary(tasks = tasks)
            }

            // Task list
            items(tasks, key = { it.id }) { task ->
                TaskCard(
                    task = task,
                    onToggleStatus = { viewModel.toggleTaskStatus(task.id) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        if (showAddTaskDialog) {
            AddTaskDialog(
                onDismiss = { showAddTaskDialog = false },
                onConfirm = { title, cat, module ->
                    viewModel.addTask(title, cat, module)
                    showAddTaskDialog = false
                }
            )
        }
    }
}

@Composable
private fun TaskQueueSummary(tasks: List<TaskItem>) {
    val runningCount = tasks.count { it.status == TaskStatus.RUNNING }
    val completedCount = tasks.count { it.status == TaskStatus.COMPLETED }
    val pendingCount = tasks.count { it.status == TaskStatus.PENDING }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            MetricStat(label = "ACTIVE", count = runningCount, color = OmniaAmber)
            MetricStat(label = "COMPLETED", count = completedCount, color = OmniaEmerald)
            MetricStat(label = "QUEUED", count = pendingCount, color = OmniaCyanPrimary)
        }
    }
}

@Composable
private fun MetricStat(label: String, count: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$count",
            style = MaterialTheme.typography.titleLarge.copy(
                fontFamily = OrbitronFamily,
                color = color,
                fontWeight = FontWeight.Bold
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = RajdhaniFamily,
                color = OmniaTextMuted,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
private fun TaskCard(
    task: TaskItem,
    onToggleStatus: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor = when (task.status) {
        TaskStatus.RUNNING -> OmniaAmber
        TaskStatus.COMPLETED -> OmniaEmerald
        TaskStatus.PENDING -> OmniaCyanPrimary
        TaskStatus.SUSPENDED -> OmniaTextMuted
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id.lowercase()}"),
        shape = RoundedCornerShape(10.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = task.id,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = task.category,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextMuted
                        )
                    )
                }

                // Status chip (clickable to cycle status)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(OmniaDarkNavy)
                        .border(1.dp, statusColor.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                        .clickable { onToggleStatus() }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = task.status.name,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = statusColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = task.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = RajdhaniFamily,
                    fontWeight = FontWeight.Bold,
                    color = OmniaTextPrimary,
                    fontSize = 16.sp
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Progress Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { task.progress },
                    modifier = Modifier
                        .weight(1f)
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = statusColor,
                    trackColor = OmniaDarkNavy
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${(task.progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = OrbitronFamily,
                        color = statusColor,
                        fontSize = 10.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Target: ${task.targetModule}",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = RajdhaniFamily,
                    color = OmniaTextMuted,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
private fun AddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("SYSTEM") }
    var module by remember { mutableStateOf("CoreExecutor") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OmniaSurface,
        title = {
            Text(
                text = "SCHEDULE OPERATOR TASK",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary
                )
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Description", color = OmniaTextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OmniaCyanPrimary,
                        unfocusedBorderColor = OmniaBorder,
                        focusedTextColor = OmniaTextPrimary,
                        unfocusedTextColor = OmniaTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category", color = OmniaTextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OmniaCyanPrimary,
                        unfocusedBorderColor = OmniaBorder,
                        focusedTextColor = OmniaTextPrimary,
                        unfocusedTextColor = OmniaTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = module,
                    onValueChange = { module = it },
                    label = { Text("Target Module", color = OmniaTextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = OmniaCyanPrimary,
                        unfocusedBorderColor = OmniaBorder,
                        focusedTextColor = OmniaTextPrimary,
                        unfocusedTextColor = OmniaTextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, category, module)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = OmniaCyanPrimary,
                    contentColor = OmniaVoidBlack
                )
            ) {
                Text("DISPATCH", fontFamily = OrbitronFamily)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = OmniaTextSecondary, fontFamily = OrbitronFamily)
            }
        }
    )
}
