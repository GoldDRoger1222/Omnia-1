# OMNIA — Master System Architecture Document
**Version:** 1.0  
**Project:** Universal Autonomous Android AI Agent  
**Package:** `com.omnia.app` (namespace `com.example`)  

---

## 1. System Overview

OMNIA is an integrated universal mobile operator designed to bridge natural language user directives to structured Android actions, business automation, e-commerce operations, and multimedia marketing pipelines without sacrificing user privacy or platform security.

### Core Workflow Loop
```
USER COMMAND (Voice / Text in English / Bangla / Banglish)
       ↓
UNDERSTANDING (Intent Parsing & Context Integration)
       ↓
PLANNING (Task Decomposition & Risk Classification)
       ↓
SECURITY CHECK (Controlled Autonomy Policy Gate: L0 - L4)
       ↓
APPROVAL (Operator Confirmation required for L2 / L3)
       ↓
EXECUTION (Android Intents / Drivers / Local Engines)
       ↓
VERIFICATION (Cryptographic Audit Ledger & Status Check)
       ↓
REPORT (Speech Synthesis & Live HUD Display)
```

---

## 2. Layered Architecture

### A. Android Client (`android/app/src/main/java/`)
- **`core/`**: Localization (`OmniaLanguage`: English, Bangla, Banglish), phrase dictionary, system constants.
- **`security/`**: Controlled autonomy policy (`RiskLevel` L0 to L4), `SecurityGate`, `PlannedAction`, cryptographic audit trail.
- **`ai/`**: Hybrid AI provider abstractions (`OnlineCloudAiProvider`, `LocalOnDeviceAiProvider`, `DeterministicOfflineFallbackProvider`, `HybridModelRouter`).
- **`brain/`**: `OmniaPlanner`, intent categories (`PRODUCT_CAMPAIGN`, `ORDER_ANALYTICS`, `APP_AUTOMATION`, `SECURITY_PROHIBITED`), task decomposer.
- **`voice/`**: Native Android `SpeechRecognizer` and `TextToSpeech` engine with Bangla (`bn_BD`) and English (`en_US`) locale adapters.
- **`memory/`**: SQLite local database (`OmniaMemoryDatabase`) with search indexing, user retention controls, and strict password/OTP exclusion.
- **`automation/`**: Universal Mobile Operator driver (`OmniaAutomationDriver`) managing intent discovery, safe execution boundaries, and user intervention triggers (`OmniaAccessibilityService` opt-in contract).
- **`business/`**: Integrated E-Commerce engine, Vision analyzer, Product studio, Social media operator, and Marketing intelligence.
- **`network/`**: `OmniaWebSocketClient` connecting to `/ws/omnia` with auto-reconnection and bearer authentication.
- **`ui/`**: Jetpack Compose Material 3 dark sci-fi interface featuring animated central AI core canvas, particle canvas, developer state controls, and 21 functional workspaces.

### B. Python Backend (`backend/app/`)
- **`api/`**: REST API endpoints and WebSocket server.
- **`core/` / `config.py`**: Configuration, environment management.
- **`security/`**: Security guard verifying action risk levels and audit hashing.
- **`planner/`**: Task planner mirroring client-side intent decomposition.
- **`schemas/`**: Pydantic and dataclass models.
- **`tests/`**: Automated test suite (`test_backend.py`).

---

## 3. Controlled Autonomy & Risk Tiers

| Tier | Classification | Behavior | Policy Gate |
|---|---|---|---|
| **L0** | Read-Only & Analysis | Data inspection, telemetry, order ledger query | Auto-approved |
| **L1** | Drafting & Reversible | Local drafting, image enhancement, catalog formatting | Auto-approved with audit record |
| **L2** | External Publication | Social media posting, public messaging | **Requires explicit operator confirmation** |
| **L3** | Financial & Orders | Placing orders, ad budgets, funds transfers | **Requires explicit operator approval** |
| **L4** | Prohibited Actions | Password extraction, OTP reading, security bypass | **Strictly blocked at planner level** |
