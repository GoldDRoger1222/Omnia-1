package com.example.omnia.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnia.model.OperatorState
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@Composable
fun TextCommandInput(
    value: String,
    onValueChange: (String) -> Unit,
    onSubmit: () -> Unit,
    state: OperatorState,
    feedback: String?,
    modifier: Modifier = Modifier
) {
    val sampleCommands = listOf(
        "RUN DIAGNOSTICS",
        "EXECUTE TSK-01",
        "THINKING PHASE",
        "SYSTEM STATUS",
        "CYCLE DEMO"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        // Console input bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            color = OmniaSurface,
            border = BorderStroke(1.dp, state.accentColor.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = "Terminal",
                    tint = state.accentColor,
                    modifier = Modifier.size(18.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = ">",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = OrbitronFamily,
                        color = state.accentColor,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.width(8.dp))

                Box(modifier = Modifier.weight(1f)) {
                    if (value.isEmpty()) {
                        Text(
                            text = "Enter operator command directive...",
                            style = TextStyle(
                                fontFamily = RajdhaniFamily,
                                fontSize = 14.sp,
                                color = OmniaTextMuted
                            )
                        )
                    }

                    BasicTextField(
                        value = value,
                        onValueChange = onValueChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("text_command_input"),
                        textStyle = TextStyle(
                            fontFamily = RajdhaniFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 15.sp,
                            color = OmniaTextPrimary
                        ),
                        cursorBrush = SolidColor(OmniaCyanPrimary),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { onSubmit() })
                    )
                }

                IconButton(
                    onClick = onSubmit,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("submit_command_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Execute Command Directive",
                        tint = if (value.isNotBlank()) OmniaCyanPrimary else OmniaTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Quick command chips
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(sampleCommands) { cmd ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(OmniaDarkNavy)
                        .border(1.dp, OmniaBorder, RoundedCornerShape(6.dp))
                        .clickable {
                            onValueChange(cmd)
                            onSubmit()
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = cmd,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 11.sp,
                            color = OmniaTextSecondary
                        )
                    )
                }
            }
        }

        // Command feedback if any
        if (feedback != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = OmniaSurfaceElevated,
                border = BorderStroke(1.dp, OmniaBorderBright)
            ) {
                Text(
                    text = "CONSOLE: $feedback",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        color = OmniaCyanPrimary,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}
