package com.omnia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.omnia.viewmodel.OmniaScreen
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaAmber
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCrimson
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily
import com.omnia.app.security.PlannedAction
import com.omnia.app.security.RiskLevel
import com.omnia.app.ui.components.OmniaHeader

// ==========================================
// 1. SECURITY CENTER SCREEN
// ==========================================
@Composable
fun SecurityCenterScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val pendingApprovals by viewModel.pendingApprovals.collectAsStateWithLifecycle()
    val auditLedger by viewModel.auditLedger.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OmniaHeader(
                title = "SECURITY CENTER",
                subtitle = "CONTROLLED AUTONOMY & APPROVAL GATES",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
            )
        }

        // Pending Approvals Section
        item {
            Text(
                text = "PENDING ACTION APPROVALS (${pendingApprovals.size}):",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = OrbitronFamily,
                    color = if (pendingApprovals.isNotEmpty()) OmniaAmber else OmniaEmerald,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        if (pendingApprovals.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = OmniaSurface,
                    border = BorderStroke(1.dp, OmniaBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = OmniaEmerald,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "No pending approvals. All active routines are nominal and verified.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextSecondary
                            )
                        )
                    }
                }
            }
        } else {
            items(pendingApprovals, key = { it.id }) { action ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_pending_approval_${action.id.take(6)}"),
                    shape = RoundedCornerShape(10.dp),
                    color = OmniaDarkNavy,
                    border = BorderStroke(1.5.dp, OmniaAmber)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ACTION: ${action.title}",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontFamily = RajdhaniFamily,
                                    fontWeight = FontWeight.Bold,
                                    color = OmniaTextPrimary
                                )
                            )
                            RiskLevelBadge(risk = action.riskLevel)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = action.payloadSummary,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextSecondary,
                                fontSize = 12.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.approvePendingAction(action) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = OmniaEmerald,
                                    contentColor = OmniaVoidBlack
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_approve_action")
                            ) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("APPROVE (L${action.riskLevel.ordinal})", fontFamily = OrbitronFamily, fontSize = 10.sp)
                            }

                            Button(
                                onClick = { viewModel.rejectPendingAction(action) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = OmniaSurfaceElevated,
                                    contentColor = OmniaCrimson
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_reject_action")
                            ) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("REJECT", fontFamily = OrbitronFamily, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // Controlled Autonomy Matrix
        item {
            Text(
                text = "CONTROLLED AUTONOMY POLICY MATRIX:",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary
                )
            )
        }

        items(RiskLevel.entries) { level ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RiskLevelBadge(risk = level)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = level.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = RajdhaniFamily,
                                fontWeight = FontWeight.Bold,
                                color = OmniaTextPrimary
                            )
                        )
                        Text(
                            text = level.description,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }

        // Audit Trail Shortcut
        item {
            Button(
                onClick = { viewModel.navigateTo(OmniaScreen.AUDIT_HISTORY) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = OmniaSurfaceElevated,
                    contentColor = OmniaCyanPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("VIEW CRYPTOGRAPHIC AUDIT LEDGER (${auditLedger.size} ENTRIES)", fontFamily = OrbitronFamily, fontSize = 11.sp)
            }
        }
    }
}

// ==========================================
// 2. AUDIT HISTORY SCREEN
// ==========================================
@Composable
fun AuditHistoryScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val auditLedger by viewModel.auditLedger.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OmniaHeader(
                title = "AUDIT LEDGER",
                subtitle = "CRYPTOGRAPHICALLY HASHED EXECUTION RECORDS",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.SECURITY_CENTER) }
            )
        }

        items(auditLedger, key = { it.id }) { record ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = record.timestamp,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextMuted
                            )
                        )
                        RiskLevelBadge(risk = record.riskLevel)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = record.actionTitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            fontWeight = FontWeight.Bold,
                            color = OmniaTextPrimary
                        )
                    )
                    Text(
                        text = "Decision: ${record.decision} • Verified: ${record.verified}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = if (record.verified) OmniaEmerald else OmniaAmber,
                            fontSize = 11.sp
                        )
                    )
                    Text(
                        text = "Hash: ${record.cryptographicHash}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaTextMuted,
                            fontSize = 9.sp
                        )
                    )
                }
            }
        }
    }
}

// ==========================================
// 3. MEMORY MANAGER SCREEN
// ==========================================
@Composable
fun MemoryManagerScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val memoryRecords by viewModel.memoryRecords.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    var newKey by remember { mutableStateOf("") }
    var newValue by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OmniaHeader(
                title = "MEMORY MANAGER",
                subtitle = "LOCAL SEARCHABLE KNOWLEDGE & RETENTION",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
            )
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.onSearchQueryChange(it) },
                placeholder = { Text("Search knowledge nodes by keyword...", color = OmniaTextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = OmniaCyanPrimary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OmniaCyanPrimary,
                    unfocusedBorderColor = OmniaBorder,
                    focusedTextColor = OmniaTextPrimary,
                    unfocusedTextColor = OmniaTextPrimary
                )
            )
        }

        // Add Note Input
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "SAVE OPERATOR CONTEXT NOTE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = newKey,
                        onValueChange = { newKey = it },
                        placeholder = { Text("Context Key (e.g. store_hours)", color = OmniaTextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OmniaCyanPrimary,
                            unfocusedBorderColor = OmniaBorder,
                            focusedTextColor = OmniaTextPrimary,
                            unfocusedTextColor = OmniaTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = newValue,
                        onValueChange = { newValue = it },
                        placeholder = { Text("Value (e.g. 10:00 AM - 10:00 PM)", color = OmniaTextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = OmniaCyanPrimary,
                            unfocusedBorderColor = OmniaBorder,
                            focusedTextColor = OmniaTextPrimary,
                            unfocusedTextColor = OmniaTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            if (newKey.isNotBlank() && newValue.isNotBlank()) {
                                viewModel.saveMemoryNote(newKey, newValue)
                                newKey = ""
                                newValue = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = OmniaCyanPrimary,
                            contentColor = OmniaVoidBlack
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SAVE TO SECURE LOCAL DATABASE", fontFamily = OrbitronFamily, fontSize = 10.sp)
                    }
                }
            }
        }

        items(memoryRecords, key = { it.id }) { record ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = record.key,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaCyanPrimary,
                                fontSize = 12.sp
                            )
                        )
                        Text(
                            text = record.value,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextPrimary
                            )
                        )
                    }
                    IconButton(onClick = { viewModel.deleteMemoryRecord(record.id) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = OmniaCrimson)
                    }
                }
            }
        }
    }
}
