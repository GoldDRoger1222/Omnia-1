package com.example.omnia.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.omnia.model.OmniaSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.omniaDataStore: DataStore<Preferences> by preferencesDataStore(name = "omnia_settings")

/**
 * Local persistence repository for OMNIA operator preferences using AndroidX DataStore.
 */
class OmniaPreferencesRepository(
    private val dataStore: DataStore<Preferences>
) {
    companion object {
        val KEY_PARTICLES_ENABLED = booleanPreferencesKey("particles_enabled")
        val KEY_PARTICLE_DENSITY = intPreferencesKey("particle_density")
        val KEY_CORE_PULSE_SPEED = floatPreferencesKey("core_pulse_speed")
        val KEY_HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val KEY_OPERATOR_NAME = stringPreferencesKey("operator_name")
        val KEY_AUTO_CYCLE_DEMO = booleanPreferencesKey("auto_cycle_demo")
    }

    val settingsFlow: Flow<OmniaSettings> = dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            OmniaSettings(
                particlesEnabled = preferences[KEY_PARTICLES_ENABLED] ?: true,
                particleDensity = preferences[KEY_PARTICLE_DENSITY] ?: 45,
                corePulseSpeed = preferences[KEY_CORE_PULSE_SPEED] ?: 1.0f,
                hapticFeedbackEnabled = preferences[KEY_HAPTIC_ENABLED] ?: true,
                autoCycleDemo = preferences[KEY_AUTO_CYCLE_DEMO] ?: false,
                operatorName = preferences[KEY_OPERATOR_NAME] ?: "OMNIA-ALPHA-01"
            )
        }

    suspend fun updateParticlesEnabled(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[KEY_PARTICLES_ENABLED] = enabled
        }
    }

    suspend fun updateParticleDensity(density: Int) {
        dataStore.edit { preferences ->
            preferences[KEY_PARTICLE_DENSITY] = density.coerceIn(10, 100)
        }
    }

    suspend fun updateCorePulseSpeed(speed: Float) {
        dataStore.edit { preferences ->
            preferences[KEY_CORE_PULSE_SPEED] = speed.coerceIn(0.5f, 2.5f)
        }
    }

    suspend fun updateHapticFeedback(enabled: Boolean) {
        dataStore.edit { preferences ->
            preferences[KEY_HAPTIC_ENABLED] = enabled
        }
    }

    suspend fun updateOperatorName(name: String) {
        dataStore.edit { preferences ->
            preferences[KEY_OPERATOR_NAME] = name.ifBlank { "OMNIA-ALPHA-01" }
        }
    }

    suspend fun resetToDefaults() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }
}
