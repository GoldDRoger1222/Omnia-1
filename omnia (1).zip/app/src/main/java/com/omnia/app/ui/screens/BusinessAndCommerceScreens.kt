package com.omnia.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.omnia.viewmodel.OmniaScreen
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaAmber
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily
import com.omnia.app.business.ECommerceOrder
import com.omnia.app.business.OrderStatus
import com.omnia.app.business.ProductLayoutFormat
import com.omnia.app.business.SocialPostDraft
import com.omnia.app.core.OmniaLanguage
import com.omnia.app.ui.components.OmniaHeader

// ==========================================
// 1. PRODUCT STUDIO SCREEN
// ==========================================
@Composable
fun ProductStudioScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.productItems.collectAsStateWithLifecycle()
    val visualAnalysis by viewModel.visualAnalysis.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OmniaHeader(
                title = "PRODUCT STUDIO",
                subtitle = "AI CATALOG GENERATION & ENHANCEMENT",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
            )
        }

        // Vision Analysis Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "VISUAL ATTRIBUTE ANALYSIS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaCyanPrimary
                            )
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = OmniaDarkNavy,
                            border = BorderStroke(1.dp, OmniaEmerald)
                        ) {
                            Text(
                                text = "VISION READY",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = OrbitronFamily,
                                    color = OmniaEmerald,
                                    fontSize = 8.sp
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = visualAnalysis?.primaryObject ?: "Ready to analyze dress attributes",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = RajdhaniFamily,
                            fontWeight = FontWeight.Bold,
                            color = OmniaTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Attributes: ${visualAnalysis?.dominantColors?.joinToString() ?: "Teal, Navy, Ice White"}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextSecondary
                        )
                    )
                    Text(
                        text = "Detected OCR Tags: ${visualAnalysis?.detectedTextOcr?.joinToString() ?: "100% ORGANIC COTTON"}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextMuted
                        )
                    )
                }
            }
        }

        // Available Multi-Format Layouts
        item {
            Text(
                text = "EXPORT FORMAT LAYOUTS:",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary
                )
            )
        }

        items(ProductLayoutFormat.entries) { fmt ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = fmt.label,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontFamily = RajdhaniFamily,
                                fontWeight = FontWeight.Bold,
                                color = OmniaTextPrimary
                            )
                        )
                        Text(
                            text = "Aspect Ratio: ${fmt.aspectRatio}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaCyanPrimary,
                                fontSize = 10.sp
                            )
                        )
                    }

                    Button(
                        onClick = { viewModel.executeUserInstruction("Generate $fmt layout") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = OmniaSurfaceElevated,
                            contentColor = OmniaCyanPrimary
                        ),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("GENERATE", fontFamily = OrbitronFamily, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. SOCIAL MEDIA MANAGER SCREEN
// ==========================================
@Composable
fun SocialMediaManagerScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val posts by viewModel.socialPosts.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OmniaHeader(
                title = "SOCIAL OPERATOR",
                subtitle = "CONTENT CALENDAR & PUBLISHING WORKFLOW",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
            )
        }

        items(posts, key = { it.id }) { post ->
            SocialPostCard(
                post = post,
                language = selectedLanguage,
                onApprovePublish = { viewModel.socialMediaOperator.approvePost(post.id) }
            )
        }
    }
}

@Composable
fun SocialPostCard(
    post: SocialPostDraft,
    language: OmniaLanguage,
    onApprovePublish: () -> Unit
) {
    val caption = when (language) {
        OmniaLanguage.BANGLA -> post.captionBangla
        OmniaLanguage.BANGLISH -> post.captionBanglish
        OmniaLanguage.ENGLISH -> post.captionEnglish
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = post.targetPlatform.platformName,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaCyanPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = OmniaDarkNavy,
                    border = BorderStroke(1.dp, if (post.isPublished) OmniaEmerald else OmniaAmber)
                ) {
                    Text(
                        text = if (post.isPublished) "PUBLISHED (VERIFIED)" else "AWAITING APPROVAL (L2)",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = if (post.isPublished) OmniaEmerald else OmniaAmber,
                            fontSize = 8.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = caption,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = RajdhaniFamily,
                    color = OmniaTextPrimary,
                    fontSize = 14.sp
                )
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = post.hashtags.joinToString(" "),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = RajdhaniFamily,
                    color = OmniaCyanGlow,
                    fontSize = 12.sp
                )
            )

            if (!post.isPublished) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onApprovePublish,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OmniaCyanPrimary,
                        contentColor = OmniaVoidBlack
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("APPROVE & BROADCAST (L2 GATE)", fontFamily = OrbitronFamily, fontSize = 11.sp)
                }
            } else if (post.liveUrl != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Verified Link: ${post.liveUrl}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        color = OmniaEmerald,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

// ==========================================
// 3. ORDER MANAGEMENT SCREEN
// ==========================================
@Composable
fun OrderManagementScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val dailyReport by viewModel.dailyReportText.collectAsStateWithLifecycle()
    val currentState by viewModel.currentState.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OmniaHeader(
                title = "ORDER MANAGEMENT",
                subtitle = "E-COMMERCE LEDGER & DISPATCH TRACKING",
                state = currentState,
                currentLanguage = selectedLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                showBackButton = true,
                onBackClick = { viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD) }
            )
        }

        // Daily Summary Report Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaDarkNavy,
                border = BorderStroke(1.dp, OmniaCyanPrimary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "LIVE ORDER REPORT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = dailyReport,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextPrimary,
                            fontSize = 13.sp
                        )
                    )
                }
            }
        }

        item {
            Text(
                text = "ACTIVE ORDERS (${orders.size}):",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary
                )
            )
        }

        items(orders, key = { it.orderId }) { order ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${order.orderId} • ${order.customerName}",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontFamily = RajdhaniFamily,
                                fontWeight = FontWeight.Bold,
                                color = OmniaTextPrimary
                            )
                        )
                        Text(
                            text = "৳${order.totalAmount}",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontFamily = OrbitronFamily,
                                fontWeight = FontWeight.Bold,
                                color = OmniaCyanPrimary
                            )
                        )
                    }
                    Text(
                        text = "Item: ${order.itemsSummary}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextSecondary
                        )
                    )
                    Text(
                        text = "Courier: ${order.courierName} (${order.trackingCode}) • Status: ${order.status.name}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaEmerald
                        )
                    )
                }
            }
        }
    }
}
