package com.example.omnia.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

data class ContextNode(
    val key: String,
    val value: String,
    val tag: String,
    val timestamp: String
)

@Composable
fun MemoryScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    val sampleNodes = listOf(
        ContextNode("operator.identity", "OMNIA-CORE-PHASE-1", "STATIC", "00:00:01"),
        ContextNode("device.platform", "Android 15 / ARM64", "HARDWARE", "00:00:02"),
        ContextNode("security.sandbox", "ENFORCED (ZERO_PERM)", "SECURITY", "00:00:03"),
        ContextNode("state_machine.active_state", "IDLE_AWAIT_DIRECTIVE", "DYNAMIC", "00:12:44"),
        ContextNode("neural.quantization", "INT8 LOCAL OPTIMIZED", "QUANTUM", "00:01:10"),
        ContextNode("persistence.backend", "ANDROIDX_DATASTORE_PREFS", "STORAGE", "00:00:05")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(16.dp)
            .testTag("memory_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "SEMANTIC MEMORY",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaCyanPrimary,
                        fontSize = 22.sp
                    )
                )
                Text(
                    text = "LOCAL CONTEXT GRAPH & STATE REGISTRY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        letterSpacing = 1.2.sp,
                        color = OmniaTextMuted
                    )
                )
            }
        }

        // Memory Metrics HUD
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MemoryGauge(label = "ACTIVE NODES", value = "256", icon = Icons.Default.Memory)
                    MemoryGauge(label = "BUFFER RETENTION", value = "99.9%", icon = Icons.Default.VerifiedUser)
                    MemoryGauge(label = "INDEX SIZE", value = "1.8 MB", icon = Icons.Default.Storage)
                }
            }
        }

        item {
            Text(
                text = "OPERATOR CONTEXT NODES",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary,
                    fontSize = 12.sp
                )
            )
        }

        // Node items
        items(sampleNodes.size) { index ->
            val node = sampleNodes[index]
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DataObject,
                                contentDescription = null,
                                tint = OmniaCyanPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = node.key,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = OrbitronFamily,
                                    color = OmniaTextPrimary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = node.value,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextSecondary,
                                fontSize = 13.sp
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(3.dp),
                            color = OmniaDarkNavy,
                            border = BorderStroke(1.dp, OmniaBorderBright)
                        ) {
                            Text(
                                text = node.tag,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = OrbitronFamily,
                                    color = OmniaEmerald,
                                    fontSize = 9.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = node.timestamp,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextMuted,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MemoryGauge(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = OmniaCyanPrimary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontFamily = OrbitronFamily,
                color = OmniaTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = RajdhaniFamily,
                color = OmniaTextMuted,
                fontSize = 10.sp
            )
        )
    }
}
