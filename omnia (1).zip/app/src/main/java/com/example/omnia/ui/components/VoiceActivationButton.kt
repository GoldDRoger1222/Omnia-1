package com.example.omnia.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.omnia.model.OperatorState
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaVoidBlack

@Composable
fun VoiceActivationButton(
    state: OperatorState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 68.dp
) {
    val isListening = (state == OperatorState.LISTENING)
    val infiniteTransition = rememberInfiniteTransition(label = "voice_btn_anim")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.28f else 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 700 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_pulse"
    )

    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = if (isListening) 0.5f else 0.15f,
        targetValue = if (isListening) 0.9f else 0.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 700 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "voice_aura_alpha"
    )

    Box(
        modifier = modifier
            .size(size + 24.dp)
            .testTag("voice_activation_button"),
        contentAlignment = Alignment.Center
    ) {
        // Outer glowing ring
        Box(
            modifier = Modifier
                .size(size * pulseScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            state.accentColor.copy(alpha = auraAlpha),
                            state.accentColor.copy(alpha = 0.05f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Middle border ring
        Box(
            modifier = Modifier
                .size(size + 6.dp)
                .clip(CircleShape)
                .border(1.5.dp, state.accentColor.copy(alpha = 0.6f), CircleShape)
        )

        // Core trigger button
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            OmniaDarkNavy,
                            OmniaVoidBlack
                        )
                    )
                )
                .border(1.5.dp, state.accentColor, CircleShape)
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Voice Activation (UI trigger)",
                tint = if (isListening) Color.White else state.accentColor,
                modifier = Modifier
                    .size(30.dp)
                    .scale(if (isListening) pulseScale else 1.0f)
            )
        }
    }
}
