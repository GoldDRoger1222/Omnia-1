package com.omnia.app.automation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SupportedAppCapability(
    val packageName: String,
    val appName: String,
    val category: String,
    val isInstalled: Boolean,
    val supportedIntentActions: List<String>,
    val requiresAccessibility: Boolean = false
)

enum class OperatorInterventionReason {
    NONE,
    CAPTCHA_DETECTED,
    BIOMETRIC_OR_PASSWORD_GATE,
    UNKNOWN_UI_SCREEN,
    RUNTIME_PERMISSION_REQUIRED,
    PAYMENT_CONFIRMATION_REQUIRED
}

data class AutomationSessionState(
    val isSessionActive: Boolean = false,
    val activePackage: String? = null,
    val stepIndex: Int = 0,
    val interventionReason: OperatorInterventionReason = OperatorInterventionReason.NONE,
    val lastActionReport: String = "Idle"
)

/**
 * Universal Mobile Operator Driver managing intent discovery,
 * safe execution boundaries, and intervention triggers.
 */
class OmniaAutomationDriver(
    private val context: Context
) {
    private val _sessionState = MutableStateFlow(AutomationSessionState())
    val sessionState: StateFlow<AutomationSessionState> = _sessionState.asStateFlow()

    fun discoverSupportedApps(): List<SupportedAppCapability> {
        val pm = context.packageManager
        val catalog = listOf(
            Triple("com.whatsapp", "WhatsApp Messenger", listOf(Intent.ACTION_SEND, Intent.ACTION_VIEW)),
            Triple("com.google.android.apps.photos", "Google Photos", listOf(Intent.ACTION_PICK, Intent.ACTION_VIEW)),
            Triple("com.android.chrome", "Google Chrome", listOf(Intent.ACTION_VIEW)),
            Triple("com.facebook.katana", "Facebook", listOf(Intent.ACTION_SEND)),
            Triple("com.instagram.android", "Instagram", listOf(Intent.ACTION_SEND))
        )

        return catalog.map { (pkg, name, actions) ->
            val installed = try {
                pm.getPackageInfo(pkg, 0)
                true
            } catch (e: PackageManager.NameNotFoundException) {
                false
            }
            SupportedAppCapability(
                packageName = pkg,
                appName = name,
                category = "COMMUNICATION_AND_MEDIA",
                isInstalled = installed,
                supportedIntentActions = actions
            )
        }
    }

    fun launchAppByIntent(packageName: String): Result<String> {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(packageName)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
                _sessionState.value = AutomationSessionState(
                    isSessionActive = true,
                    activePackage = packageName,
                    lastActionReport = "Launched package '$packageName' via Android Intent Broker."
                )
                Result.success("Successfully launched $packageName")
            } catch (e: Exception) {
                Result.failure(e)
            }
        } else {
            Result.failure(IllegalStateException("Package '$packageName' not installed or has no launchable Activity."))
        }
    }

    fun launchShareIntent(text: String, title: String = "Share Content"): Boolean {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(sendIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun triggerIntervention(reason: OperatorInterventionReason, details: String) {
        _sessionState.value = _sessionState.value.copy(
            interventionReason = reason,
            lastActionReport = "PAUSED FOR USER INTERVENTION: $details"
        )
    }

    fun resumeSession() {
        _sessionState.value = _sessionState.value.copy(
            interventionReason = OperatorInterventionReason.NONE,
            lastActionReport = "Operator resumed control."
        )
    }
}

/**
 * Opt-in Accessibility Service for user-approved navigation.
 * Disabled by default. Only active when explicitly enabled by user in Android Accessibility Settings.
 */
class OmniaAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Inspect supported UI events strictly for active automation sessions
        val eventPackage = event?.packageName?.toString() ?: return
        val eventType = event.eventType

        // Safety detection for passwords or CAPTCHA nodes
        val source = event.source
        if (source != null) {
            if (source.isPassword) {
                // Security safeguard: Never inspect password fields
                source.recycle()
                return
            }
            source.recycle()
        }
    }

    override fun onInterrupt() {}
}
