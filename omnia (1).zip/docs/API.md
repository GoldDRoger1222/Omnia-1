# OMNIA — Backend API & WebSocket Specification
**Version:** 1.0  
**Base URL:** `http://localhost:8000/api/v1`  
**WebSocket URL:** `ws://localhost:8000/ws/omnia`  

---

## 1. REST Endpoints

### 1.1 `GET /api/v1/health`
Returns service operational health.
```json
{
  "status": "HEALTHY",
  "service": "OMNIA Mobile Operator Backend",
  "version": "1.0.0",
  "timestamp": 1730837500.0
}
```

### 1.2 `GET /api/v1/status`
Returns real-time telemetry and active task metrics.
```json
{
  "neural_engine": "NOMINAL (99.8%)",
  "active_mesh": "L1-MESH QUANTUM LINK",
  "controlled_autonomy": "STRICT_ENFORCEMENT",
  "active_tasks_count": 3,
  "audit_records_count": 12
}
```

### 1.3 `POST /api/v1/commands`
Submits a natural language command for understanding, planning, and security classification.
**Request Body:**
```json
{
  "prompt": "OMNIA, ei dress er product campaign ready kor",
  "user_id": "omnia_primary_user"
}
```
**Response:**
```json
{
  "task_id": "TSK-A91B4C",
  "intent_category": "PRODUCT_CAMPAIGN",
  "detected_language": "bng",
  "summary": "Product campaign preparation pipeline.",
  "actions": [
    {
      "action_id": "ACT-1201",
      "title": "Analyze product image attributes",
      "risk_level": "L1",
      "target_module": "VisionEngine",
      "status": "APPROVED"
    },
    {
      "action_id": "ACT-1202",
      "title": "Broadcast product campaign to Facebook & Instagram",
      "risk_level": "L2",
      "target_module": "SocialMediaOperator",
      "status": "PENDING_APPROVAL",
      "policy_reason": "AWAITING_APPROVAL: Explicit confirmation required before execution."
    }
  ],
  "requires_approval": true,
  "highest_risk_level": "L2"
}
```

### 1.4 `POST /api/v1/tasks/{task_id}/approve`
Explicitly approves an action waiting at an L2 or L3 security gate.
```json
{
  "status": "SUCCESS",
  "task_id": "TSK-A91B4C"
}
```

### 1.5 `POST /api/v1/tasks/{task_id}/cancel`
Rejects/cancels pending task actions.

### 1.6 `GET /api/v1/providers`
Lists configured and fallback AI providers with capability flags.

### 1.7 `GET /api/v1/integrations`
Lists supported application packages and intent capabilities.

### 1.8 `GET /api/v1/audit`
Returns the cryptographic audit log with SHA-256 signatures.

---

## 2. WebSocket Protocol (`/ws/omnia`)

- **Handshake Header:** `Authorization: Bearer <omnia_token>`
- **Message Format:** JSON
- **Events:**
  - `TELEMETRY_STREAM`: Periodic system and core status.
  - `STATE_CHANGE`: Core state machine transition event.
  - `APPROVAL_REQUIRED`: Push notification for pending L2/L3 actions.
