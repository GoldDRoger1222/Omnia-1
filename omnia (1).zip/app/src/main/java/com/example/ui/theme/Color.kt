package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sci-Fi Dark Space Palette
val OmniaVoidBlack = Color(0xFF070A0F)
val OmniaDarkNavy = Color(0xFF0C101A)
val OmniaSurface = Color(0xFF101726)
val OmniaSurfaceVariant = Color(0xFF162032)
val OmniaSurfaceElevated = Color(0xFF1D2B42)
val OmniaBorder = Color(0xFF1E324A)
val OmniaBorderBright = Color(0xFF2B4D72)

// Neon & Core Accent Colors
val OmniaCyanPrimary = Color(0xFF00F0FF)
val OmniaCyanGlow = Color(0xFF4DF3FF)
val OmniaCyanDeep = Color(0xFF00A3B0)
val OmniaNeonBlue = Color(0xFF2979FF)
val OmniaEmerald = Color(0xFF00E5A3)
val OmniaViolet = Color(0xFF7C4DFF)
val OmniaAmber = Color(0xFFFFAB00)
val OmniaCrimson = Color(0xFFFF2A55)

// Text Colors
val OmniaTextPrimary = Color(0xFFE8F6FA)
val OmniaTextSecondary = Color(0xFF8FA8BF)
val OmniaTextMuted = Color(0xFF4C667D)
val OmniaTextCyan = Color(0xFF00F0FF)

// State-Specific Colors
val StateIdleColor = Color(0xFF00F0FF)
val StateListeningColor = Color(0xFF5CE1E6)
val StateThinkingColor = Color(0xFF9D4EDD)
val StateExecutingColor = Color(0xFFFFB703)
val StateSpeakingColor = Color(0xFF00F5D4)
val StateErrorColor = Color(0xFFFF0054)
