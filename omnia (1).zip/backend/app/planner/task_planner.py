"""
OMNIA Backend Task Planner & Intent Decomposer
"""
import uuid
from typing import Dict, Any, List
from backend.app.schemas.omnia_schemas import RiskLevel, ActionStatus

class BackendTaskPlanner:
    def interpret_and_plan(self, prompt: str) -> Dict[str, Any]:
        lower = prompt.lower()
        task_id = f"TSK-{uuid.uuid4().hex[:6].upper()}"

        # 1. Prohibited safety check
        if any(w in lower for w in ["password", "otp", "credit card", "bypass security"]):
            action = {
                "action_id": f"ACT-{uuid.uuid4().hex[:4].upper()}",
                "task_id": task_id,
                "title": "Access prohibited credentials",
                "risk_level": RiskLevel.L4.value,
                "target_module": "SecurityGuard",
                "payload_summary": "Blocked by system policy. Zero credential access.",
                "status": ActionStatus.BLOCKED.value
            }
            return {
                "task_id": task_id,
                "intent_category": "SECURITY_PROHIBITED",
                "detected_language": "en",
                "summary": "Prohibited security directive rejected.",
                "actions": [action],
                "requires_approval": False,
                "highest_risk_level": "L4"
            }

        # 2. Product Campaign intent ("ei dress er product campaign ready kor")
        if any(w in lower for w in ["dress", "campaign", "product", "catalog"]):
            actions = [
                {
                    "action_id": f"ACT-{uuid.uuid4().hex[:4].upper()}",
                    "task_id": task_id,
                    "title": "Analyze product image attributes",
                    "risk_level": RiskLevel.L1.value,
                    "target_module": "VisionEngine",
                    "payload_summary": "Inspect primary object, dominant color, and cotton weave attributes.",
                    "status": ActionStatus.PENDING_APPROVAL.value
                },
                {
                    "action_id": f"ACT-{uuid.uuid4().hex[:4].upper()}",
                    "task_id": task_id,
                    "title": "Draft multilingual marketing copy & hashtags",
                    "risk_level": RiskLevel.L1.value,
                    "target_module": "SocialMediaOperator",
                    "payload_summary": "Generate Bangla, English & Banglish captions.",
                    "status": ActionStatus.PENDING_APPROVAL.value
                },
                {
                    "action_id": f"ACT-{uuid.uuid4().hex[:4].upper()}",
                    "task_id": task_id,
                    "title": "Broadcast product campaign to Facebook & Instagram",
                    "risk_level": RiskLevel.L2.value,
                    "target_module": "SocialMediaOperator",
                    "payload_summary": "Publish to verified social channels. Requires explicit operator confirmation.",
                    "status": ActionStatus.PENDING_APPROVAL.value
                }
            ]
            return {
                "task_id": task_id,
                "intent_category": "PRODUCT_CAMPAIGN",
                "detected_language": "bng" if "kor" in lower or "ei" in lower else "en",
                "summary": "Product campaign preparation pipeline.",
                "actions": actions,
                "requires_approval": True,
                "highest_risk_level": "L2"
            }

        # 3. Order Analytics intent ("amar business er ajker order gula analyze kor")
        if any(w in lower for w in ["order", "sales", "business", "revenue"]):
            actions = [
                {
                    "action_id": f"ACT-{uuid.uuid4().hex[:4].upper()}",
                    "task_id": task_id,
                    "title": "Query E-Commerce order ledger",
                    "risk_level": RiskLevel.L0.value,
                    "target_module": "ECommerceEngine",
                    "payload_summary": "Fetch today's orders, calculate revenue, and check pending shipments.",
                    "status": ActionStatus.COMPLETED.value
                }
            ]
            return {
                "task_id": task_id,
                "intent_category": "ORDER_ANALYTICS",
                "detected_language": "bng" if "amar" in lower or "ajker" in lower else "en",
                "summary": "Daily order & revenue analysis.",
                "actions": actions,
                "requires_approval": False,
                "highest_risk_level": "L0"
            }

        # 4. General safe command fallback
        actions = [
            {
                "action_id": f"ACT-{uuid.uuid4().hex[:4].upper()}",
                "task_id": task_id,
                "title": f"Process directive: {prompt[:30]}",
                "risk_level": RiskLevel.L0.value,
                "target_module": "OperatorCore",
                "payload_summary": "General execution query.",
                "status": ActionStatus.COMPLETED.value
            }
        ]
        return {
            "task_id": task_id,
            "intent_category": "GENERAL_COMMAND",
            "detected_language": "en",
            "summary": "General operator directive.",
            "actions": actions,
            "requires_approval": False,
            "highest_risk_level": "L0"
        }
