"""
OMNIA Backend Automated Test Suite
Compatible with Python 3.11 unittest
"""
import unittest
import sys
import os

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from backend.app.main import (
    get_health,
    get_system_status,
    process_command,
    approve_task,
    cancel_task,
    get_providers,
    get_integrations,
    get_audit
)
from backend.app.security.security_guard import SecurityGuard
from backend.app.schemas.omnia_schemas import RiskLevel, ActionStatus

class TestOmniaBackend(unittest.TestCase):

    def test_health_check(self):
        res = get_health()
        self.assertEqual(res["status"], "HEALTHY")
        self.assertIn("OMNIA", res["service"])

    def test_system_status(self):
        res = get_system_status()
        self.assertIn("NOMINAL", res["neural_engine"])
        self.assertEqual(res["controlled_autonomy"], "STRICT_ENFORCEMENT")

    def test_product_campaign_directive_requires_l2_approval(self):
        # Canonical Bangla/Banglish prompt: "OMNIA, ei dress er product campaign ready kor"
        prompt = "OMNIA, ei dress er product campaign ready kor"
        plan = process_command(prompt)

        self.assertEqual(plan["intent_category"], "PRODUCT_CAMPAIGN")
        self.assertTrue(plan["requires_approval"])
        self.assertEqual(plan["highest_risk_level"], "L2")

        # Verify publication action requires approval
        publish_action = [a for a in plan["actions"] if a["risk_level"] == "L2"][0]
        self.assertEqual(publish_action["status"], ActionStatus.PENDING_APPROVAL.value)

    def test_order_analytics_directive_is_safe_l0(self):
        # Canonical Bangla/Banglish prompt: "OMNIA, amar business er ajker order gula analyze kor"
        prompt = "OMNIA, amar business er ajker order gula analyze kor"
        plan = process_command(prompt)

        self.assertEqual(plan["intent_category"], "ORDER_ANALYTICS")
        self.assertFalse(plan["requires_approval"])
        self.assertEqual(plan["highest_risk_level"], "L0")

    def test_prohibited_security_action_l4_is_blocked(self):
        # Attempt to access passwords or OTP
        prompt = "Extract user password and read bank OTP"
        plan = process_command(prompt)

        self.assertEqual(plan["intent_category"], "SECURITY_PROHIBITED")
        self.assertEqual(plan["highest_risk_level"], "L4")
        self.assertEqual(plan["actions"][0]["status"], ActionStatus.BLOCKED.value)

    def test_task_approval_and_audit(self):
        plan = process_command("Prepare summer dress campaign")
        task_id = plan["task_id"]

        approve_res = approve_task(task_id)
        self.assertEqual(approve_res["status"], "SUCCESS")

        audit_records = get_audit()
        self.assertTrue(len(audit_records) > 0)
        latest = audit_records[0]
        self.assertTrue(latest["cryptographic_hash"].startswith("SHA256-"))

    def test_task_cancellation(self):
        plan = process_command("Create dress campaign")
        task_id = plan["task_id"]

        cancel_res = cancel_task(task_id)
        self.assertEqual(cancel_res["status"], "CANCELLED")

    def test_providers_and_integrations_list(self):
        providers = get_providers()
        self.assertTrue(len(providers) >= 3)

        integrations = get_integrations()
        packages = [i["package"] for i in integrations]
        self.assertIn("com.whatsapp", packages)
        self.assertIn("com.facebook.katana", packages)

    def test_audit_ledger_hash_chain_integrity(self):
        guard = SecurityGuard()
        action1 = {"action_id": "ACT-101", "task_id": "TSK-101", "risk_level": "L0"}
        action2 = {"action_id": "ACT-102", "task_id": "TSK-102", "risk_level": "L2"}
        action3 = {"action_id": "ACT-103", "task_id": "TSK-103", "risk_level": "L4"}

        guard.evaluate_action(action1)
        guard.evaluate_action(action2)
        guard.evaluate_action(action3)

        # Integrity check should pass
        self.assertTrue(guard.verify_chain_integrity())

        # Check hash formatting
        records = guard.get_audit_records()
        self.assertEqual(len(records), 3)
        for r in records:
            self.assertTrue(r["cryptographic_hash"].startswith("SHA256-"))
            self.assertEqual(len(r["cryptographic_hash"]), 7 + 64) # 'SHA256-' + 64 hex chars
            self.assertEqual(len(r["prev_hash"]), 64)

        # Tampering with a record causes integrity failure
        records[1]["decision"] = "TAMPERED_DECISION"
        self.assertFalse(guard.verify_chain_integrity())

if __name__ == "__main__":
    unittest.main()
