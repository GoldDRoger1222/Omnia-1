package com.example.omnia.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.StateErrorColor
import com.example.ui.theme.StateExecutingColor
import com.example.ui.theme.StateIdleColor
import com.example.ui.theme.StateListeningColor
import com.example.ui.theme.StateSpeakingColor
import com.example.ui.theme.StateThinkingColor

/**
 * Core operational states for the OMNIA Mobile Operator State Machine.
 */
enum class OperatorState(
    val code: String,
    val displayName: String,
    val description: String,
    val accentColor: Color,
    val pulseSpeedMultiplier: Float
) {
    IDLE(
        code = "IDL-01",
        displayName = "IDLE (STANDBY)",
        description = "Core online. Quantum harmonic resonance steady. Awaiting operator directive.",
        accentColor = StateIdleColor,
        pulseSpeedMultiplier = 1.0f
    ),
    LISTENING(
        code = "LST-02",
        displayName = "LISTENING",
        description = "Acoustic sensor buffer active. Capturing frequency stream and operator voice packet.",
        accentColor = StateListeningColor,
        pulseSpeedMultiplier = 2.2f
    ),
    THINKING(
        code = "THK-03",
        displayName = "THINKING",
        description = "Neural quantum calculation active. Synthesizing semantic graph and action graph.",
        accentColor = StateThinkingColor,
        pulseSpeedMultiplier = 3.0f
    ),
    EXECUTING(
        code = "EXE-04",
        displayName = "EXECUTING",
        description = "Dispatching pipeline subroutines. Executing orchestrated operator workflow.",
        accentColor = StateExecutingColor,
        pulseSpeedMultiplier = 2.8f
    ),
    SPEAKING(
        code = "SPK-05",
        displayName = "SPEAKING",
        description = "Modulating acoustic response. Harmonic audio stream broadcasting.",
        accentColor = StateSpeakingColor,
        pulseSpeedMultiplier = 1.8f
    ),
    ERROR(
        code = "ERR-99",
        displayName = "ERROR (ANOMALY)",
        description = "Core telemetry threshold warning. Fallback safe mode engaged.",
        accentColor = StateErrorColor,
        pulseSpeedMultiplier = 3.5f
    );

    /**
     * Set of valid state transitions from this state.
     */
    fun canTransitionTo(nextState: OperatorState): Boolean {
        if (nextState == ERROR) return true // Any state can enter ERROR
        return when (this) {
            IDLE -> nextState in listOf(LISTENING, THINKING, EXECUTING)
            LISTENING -> nextState in listOf(THINKING, IDLE)
            THINKING -> nextState in listOf(EXECUTING, SPEAKING, IDLE)
            EXECUTING -> nextState in listOf(SPEAKING, IDLE, THINKING)
            SPEAKING -> nextState in listOf(IDLE, LISTENING)
            ERROR -> nextState in listOf(IDLE) // Recovery to IDLE
        }
    }
}
