package com.example.omnia.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnia.model.ActivityLog
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@Composable
fun TaskActivityPanel(
    logs: List<ActivityLog>,
    modifier: Modifier = Modifier,
    maxHeight: Int = 180
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_activity_panel"),
        shape = RoundedCornerShape(12.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ListAlt,
                        contentDescription = "Activity Log",
                        tint = OmniaCyanPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TASK ACTIVITY STREAM",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaCyanPrimary,
                            fontSize = 11.sp
                        )
                    )
                }

                Text(
                    text = "${logs.size} EVENTS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        color = OmniaTextMuted,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Log items
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = maxHeight.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(logs, key = { it.id }) { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(OmniaDarkNavy, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // State marker dot
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(log.state.accentColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        // Timestamp
                        Text(
                            text = log.timestamp,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextMuted,
                                fontSize = 11.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        // State tag
                        Text(
                            text = "[${log.state.code}]",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = OrbitronFamily,
                                color = log.state.accentColor,
                                fontSize = 9.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        // Message
                        Text(
                            text = log.message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = if (log.isAnomaly) log.state.accentColor else OmniaTextPrimary,
                                fontSize = 12.sp
                            ),
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
