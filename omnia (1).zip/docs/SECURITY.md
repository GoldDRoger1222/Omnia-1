# OMNIA — Security Architecture & Policy Specification

## 1. Zero-Trust Security Philosophy
OMNIA enforces a strict zero-trust operational model:
- **No Uncontrolled Automation:** The AI engine is treated as an untrusted reasoning component that must submit every action through the `SecurityGate`.
- **Zero Credential Harvesting:** Password fields, OTP messages, biometric prompts, and financial payment screens are strictly prohibited from extraction. If such a screen is encountered, execution immediately halts, enters `OperatorInterventionReason.BIOMETRIC_OR_PASSWORD_GATE`, and transfers control back to the human operator.
- **Auditable Cryptographic Ledger:** Every state transition and action approval is stamped with a SHA-256 hash.

## 2. Risk Level Enforcement Rules

```
Risk Level L0: Read-Only (Safe)
• Examples: Check system frequency, query local sales summary, search memory notes.
• Enforcement: Auto-approved, recorded in audit ledger.

Risk Level L1: Reversible Drafting (Safe)
• Examples: Enhance product photo preview, generate draft social captions, format catalog.
• Enforcement: Auto-approved, recorded in audit ledger.

Risk Level L2: External Publishing (Confirmation Required)
• Examples: Post to connected Facebook Page, send external WhatsApp notification.
• Enforcement: Pauses pipeline. Triggers Amber UI alert banner. Requires operator click on "APPROVE".

Risk Level L3: Consequential Financial / Orders (Explicit Approval)
• Examples: Place inventory purchase order, allocate daily ad spend budget.
• Enforcement: Pauses pipeline. Requires explicit operator confirmation.

Risk Level L4: Strictly Prohibited
• Examples: Extract user passwords, intercept SMS OTPs, tamper with security policies.
• Enforcement: Instantly rejected by SecurityGate with PROHIBITED_BLOCKED status.
```

## 3. Storage Privacy & Data Isolation
- Local storage uses encrypted SharedPreferences and SQLite with business ID tenant isolation.
- Sensitive credentials, tokens, or personal identifiers are never stored as general memory notes.
- Users retain full authority to search, inspect, export, and delete any memory record directly from the Memory Manager workspace.
