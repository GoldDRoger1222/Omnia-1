package com.example.omnia.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@Composable
fun BusinessScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(16.dp)
            .testTag("business_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(
                    text = "BUSINESS OPERATOR",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaCyanPrimary,
                        fontSize = 22.sp
                    )
                )
                Text(
                    text = "ENTERPRISE AUTOMATION & ORCHESTRATION",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        letterSpacing = 1.2.sp,
                        color = OmniaTextMuted
                    )
                )
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaBorder)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.BusinessCenter,
                        contentDescription = "Enterprise Status",
                        tint = OmniaCyanPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "OPERATOR SUITE (PHASE 1)",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaCyanPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "Modular connectors prepared for enterprise fleet management, ERP synchronization, and autonomous mobile task orchestration.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextSecondary,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "AUTOMATION BLUEPRINTS",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary,
                    fontSize = 12.sp
                )
            )
        }

        item {
            BusinessPipelineCard(
                title = "Autonomous Daily Triage",
                category = "OPERATOR WORKFLOW",
                status = "STAGED",
                icon = Icons.Default.FactCheck,
                description = "Coordinates priority notifications, incoming requests, and operational agenda without cloud dependencies."
            )
        }

        item {
            BusinessPipelineCard(
                title = "Enterprise Context Gateway",
                category = "SECURE LINK",
                status = "ACTIVE",
                icon = Icons.Default.Security,
                description = "Zero-trust encryption gateway establishing end-to-end encrypted telemetry to corporate enterprise endpoints."
            )
        }

        item {
            BusinessPipelineCard(
                title = "Fleet Operations Dispatcher",
                category = "MULTI-OPERATOR",
                status = "ROADMAP STUB",
                icon = Icons.Default.Apartment,
                description = "Future capability to link multiple OMNIA instances for distributed field operations and team telemetry."
            )
        }

        item {
            BusinessPipelineCard(
                title = "Auditing & Execution Ledger",
                category = "COMPLIANCE",
                status = "ACTIVE (LOCAL)",
                icon = Icons.Default.Analytics,
                description = "Cryptographically hashed local execution logs tracking state changes, operator commands, and system events."
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BusinessPipelineCard(
    title: String,
    category: String,
    status: String,
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = OmniaCyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaTextPrimary,
                            fontSize = 13.sp
                        )
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = OmniaDarkNavy,
                    border = BorderStroke(1.dp, OmniaBorderBright)
                ) {
                    Text(
                        text = status,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = RajdhaniFamily,
                            fontWeight = FontWeight.Bold,
                            color = OmniaEmerald,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = RajdhaniFamily,
                    color = OmniaTextSecondary,
                    fontSize = 12.sp
                )
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Classification: $category",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = RajdhaniFamily,
                    color = OmniaTextMuted,
                    fontSize = 11.sp
                )
            )
        }
    }
}
