package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.omnia.model.NavigationTab
import com.example.omnia.ui.components.OmniaBottomNavigation
import com.example.omnia.ui.screens.BusinessScreen
import com.example.omnia.ui.screens.SettingsScreen
import com.example.omnia.ui.screens.TasksScreen
import com.example.omnia.ui.screens.WorkspaceScreen
import com.example.omnia.viewmodel.OmniaScreen
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.OmniaVoidBlack
import com.omnia.app.ui.screens.AppIntegrationsScreen
import com.omnia.app.ui.screens.AuditHistoryScreen
import com.omnia.app.ui.screens.MainDashboardScreen
import com.omnia.app.ui.screens.MemoryManagerScreen
import com.omnia.app.ui.screens.OrderManagementScreen
import com.omnia.app.ui.screens.ProductStudioScreen
import com.omnia.app.ui.screens.SecurityCenterScreen
import com.omnia.app.ui.screens.SocialMediaManagerScreen
import com.omnia.app.ui.screens.TaskPlannerScreen
import com.omnia.app.ui.screens.VoiceWorkspaceScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                OmniaApp()
            }
        }
    }
}

@Composable
fun OmniaApp(
    viewModel: OmniaViewModel = viewModel()
) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    // Handle back button to return to Main Dashboard when on sub-screens
    BackHandler(enabled = (currentScreen != OmniaScreen.MAIN_DASHBOARD || selectedTab != NavigationTab.HOME)) {
        if (currentScreen != OmniaScreen.MAIN_DASHBOARD) {
            viewModel.navigateTo(OmniaScreen.MAIN_DASHBOARD)
        } else {
            viewModel.selectTab(NavigationTab.HOME)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(OmniaVoidBlack),
        containerColor = OmniaVoidBlack,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            OmniaBottomNavigation(
                selectedTab = selectedTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            when (currentScreen) {
                OmniaScreen.MAIN_DASHBOARD -> MainDashboardScreen(viewModel = viewModel)
                OmniaScreen.TASK_PLANNER -> TaskPlannerScreen(viewModel = viewModel)
                OmniaScreen.TASK_EXECUTION_MONITOR -> TasksScreen(viewModel = viewModel)
                OmniaScreen.APP_INTEGRATIONS -> AppIntegrationsScreen(viewModel = viewModel)
                OmniaScreen.VOICE_WORKSPACE -> VoiceWorkspaceScreen(viewModel = viewModel)
                OmniaScreen.PRODUCT_STUDIO -> ProductStudioScreen(viewModel = viewModel)
                OmniaScreen.SOCIAL_MEDIA_MANAGER -> SocialMediaManagerScreen(viewModel = viewModel)
                OmniaScreen.ORDER_MANAGEMENT -> OrderManagementScreen(viewModel = viewModel)
                OmniaScreen.SECURITY_CENTER -> SecurityCenterScreen(viewModel = viewModel)
                OmniaScreen.AUDIT_HISTORY -> AuditHistoryScreen(viewModel = viewModel)
                OmniaScreen.MEMORY_MANAGER -> MemoryManagerScreen(viewModel = viewModel)
                OmniaScreen.BUSINESS_DASHBOARD -> BusinessScreen(viewModel = viewModel)
                OmniaScreen.GENERAL_SETTINGS -> SettingsScreen(viewModel = viewModel)
                else -> MainDashboardScreen(viewModel = viewModel)
            }
        }
    }
}
