package com.example.omnia.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.omnia.data.OmniaPreferencesRepository
import com.example.omnia.data.omniaDataStore
import com.example.omnia.model.ActivityLog
import com.example.omnia.model.NavigationTab
import com.example.omnia.model.NetworkTelemetry
import com.example.omnia.model.OmniaSettings
import com.example.omnia.model.OperatorState
import com.example.omnia.model.SystemTelemetry
import com.example.omnia.model.TaskItem
import com.example.omnia.model.TaskStatus
import com.example.omnia.state.OperatorStateMachine
import com.omnia.app.ai.AiCompletionRequest
import com.omnia.app.ai.AiModelConfig
import com.omnia.app.ai.DeterministicOfflineFallbackProvider
import com.omnia.app.ai.HybridModelRouter
import com.omnia.app.ai.LocalOnDeviceAiProvider
import com.omnia.app.ai.OnlineCloudAiProvider
import com.omnia.app.ai.ProviderType
import com.omnia.app.automation.OmniaAutomationDriver
import com.omnia.app.automation.SupportedAppCapability
import com.omnia.app.brain.CommandIntent
import com.omnia.app.brain.ExecutionPlan
import com.omnia.app.brain.OmniaPlanner
import com.omnia.app.business.ECommerceEngine
import com.omnia.app.business.ECommerceOrder
import com.omnia.app.business.InventoryItem
import com.omnia.app.business.MarketingIntelligence
import com.omnia.app.business.OrderStatus
import com.omnia.app.business.ProductStudioItem
import com.omnia.app.business.SocialMediaOperator
import com.omnia.app.business.SocialPostDraft
import com.omnia.app.business.VisionEngine
import com.omnia.app.business.VisualAnalysisResult
import com.omnia.app.core.OmniaLanguage
import com.omnia.app.core.OmniaLocalization
import com.omnia.app.memory.MemoryRecord
import com.omnia.app.memory.OmniaMemoryDatabase
import com.omnia.app.network.OmniaWebSocketClient
import com.omnia.app.security.AuditRecord
import com.omnia.app.security.PlannedAction
import com.omnia.app.security.RiskLevel
import com.omnia.app.security.SecurityGate
import com.omnia.app.voice.VoiceEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

enum class OmniaScreen(val title: String, val category: String) {
    SPLASH_ONBOARDING("Onboarding", "SYSTEM"),
    MAIN_DASHBOARD("Main AI Dashboard", "CORE"),
    VOICE_WORKSPACE("Voice Workspace", "CORE"),
    AI_COMMAND_WORKSPACE("AI Command Console", "CORE"),
    TASK_PLANNER("Task Planner", "TASKS"),
    TASK_EXECUTION_MONITOR("Execution Monitor", "TASKS"),
    APP_INTEGRATIONS("App Integrations", "AUTOMATION"),
    PERMISSIONS_MANAGER("Permissions Manager", "SECURITY"),
    PRODUCT_STUDIO("Product Image Studio", "BUSINESS"),
    SOCIAL_MEDIA_MANAGER("Social Media Operator", "BUSINESS"),
    BUSINESS_DASHBOARD("Business Hub", "BUSINESS"),
    INVENTORY_MANAGER("Product & Inventory", "ECOMMERCE"),
    ORDER_MANAGEMENT("Order Management", "ECOMMERCE"),
    CUSTOMER_SUPPORT("Customer Support Hub", "BUSINESS"),
    MARKETING_ANALYTICS("Marketing Analytics", "BUSINESS"),
    AI_PROVIDER_SETTINGS("AI Provider Settings", "SETTINGS"),
    LOCAL_AI_SETTINGS("Local AI Settings", "SETTINGS"),
    MEMORY_MANAGER("Memory Manager", "MEMORY"),
    SECURITY_CENTER("Security & Approvals", "SECURITY"),
    AUDIT_HISTORY("Audit & Ledger", "SECURITY"),
    GENERAL_SETTINGS("General Settings", "SETTINGS")
}

class OmniaViewModel(
    application: Application,
    private val preferencesRepository: OmniaPreferencesRepository
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application,
        OmniaPreferencesRepository(application.omniaDataStore)
    )

    // Core Systems
    val stateMachine = OperatorStateMachine(viewModelScope)
    val currentState: StateFlow<OperatorState> = stateMachine.currentState
    val activityLogs = stateMachine.activityLogs
    val lastTransitionMessage = stateMachine.lastTransitionMessage
    val isAutoDemoRunning = stateMachine.isAutoDemoRunning

    // Multilingual support
    private val _selectedLanguage = MutableStateFlow(OmniaLanguage.ENGLISH)
    val selectedLanguage: StateFlow<OmniaLanguage> = _selectedLanguage.asStateFlow()

    // Navigation (Screen and Tab)
    private val _currentScreen = MutableStateFlow(OmniaScreen.MAIN_DASHBOARD)
    val currentScreen: StateFlow<OmniaScreen> = _currentScreen.asStateFlow()

    private val _selectedTab = MutableStateFlow(NavigationTab.HOME)
    val selectedTab: StateFlow<NavigationTab> = _selectedTab.asStateFlow()

    // Controlled Autonomy & Security
    val securityGate = SecurityGate()
    private val _pendingApprovals = MutableStateFlow<List<PlannedAction>>(emptyList())
    val pendingApprovals: StateFlow<List<PlannedAction>> = _pendingApprovals.asStateFlow()

    private val _auditLedger = MutableStateFlow<List<AuditRecord>>(emptyList())
    val auditLedger: StateFlow<List<AuditRecord>> = _auditLedger.asStateFlow()

    // AI Providers & Router
    val onlineCloudProvider = OnlineCloudAiProvider(
        AiModelConfig(
            id = "gemini_online",
            name = "Gemini Flash / Pro (Online)",
            providerType = ProviderType.ONLINE_CLOUD,
            endpointUrl = "https://generativelanguage.googleapis.com",
            apiKey = "",
            supportsVision = true
        )
    )
    val localProvider = LocalOnDeviceAiProvider()
    val modelRouter = HybridModelRouter(onlineCloudProvider, localProvider)

    // Planner
    val planner = OmniaPlanner(securityGate, modelRouter)
    private val _activePlan = MutableStateFlow<ExecutionPlan?>(null)
    val activePlan: StateFlow<ExecutionPlan?> = _activePlan.asStateFlow()

    // Memory Database
    val memoryDatabase = OmniaMemoryDatabase(application)
    private val _memoryRecords = MutableStateFlow<List<MemoryRecord>>(emptyList())
    val memoryRecords: StateFlow<List<MemoryRecord>> = _memoryRecords.asStateFlow()
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Automation & Intent Broker
    val automationDriver = OmniaAutomationDriver(application)
    private val _supportedApps = MutableStateFlow<List<SupportedAppCapability>>(emptyList())
    val supportedApps: StateFlow<List<SupportedAppCapability>> = _supportedApps.asStateFlow()

    // Business Engines
    val visionEngine = VisionEngine()
    val socialMediaOperator = SocialMediaOperator()
    val eCommerceEngine = ECommerceEngine()
    val marketingIntelligence = MarketingIntelligence()

    private val _visualAnalysis = MutableStateFlow<VisualAnalysisResult?>(null)
    val visualAnalysis: StateFlow<VisualAnalysisResult?> = _visualAnalysis.asStateFlow()

    private val _socialPosts = MutableStateFlow<List<SocialPostDraft>>(emptyList())
    val socialPosts: StateFlow<List<SocialPostDraft>> = _socialPosts.asStateFlow()

    private val _orders = MutableStateFlow<List<ECommerceOrder>>(emptyList())
    val orders: StateFlow<List<ECommerceOrder>> = _orders.asStateFlow()

    private val _inventory = MutableStateFlow<List<InventoryItem>>(emptyList())
    val inventory: StateFlow<List<InventoryItem>> = _inventory.asStateFlow()

    private val _dailyReportText = MutableStateFlow("")
    val dailyReportText: StateFlow<String> = _dailyReportText.asStateFlow()

    // Product Studio Items
    private val _productItems = MutableStateFlow<List<ProductStudioItem>>(
        listOf(
            ProductStudioItem(
                id = "PROD-01",
                title = "Embroidered Cotton Festive Dress",
                category = "Apparel",
                price = 2450.0,
                sizes = listOf("S", "M", "L", "XL"),
                stockCount = 34,
                description = "Handcrafted organic cotton festive dress with floral embroidery and breathable weave."
            )
        )
    )
    val productItems: StateFlow<List<ProductStudioItem>> = _productItems.asStateFlow()

    // Voice Engine
    val voiceEngine = VoiceEngine(application) { spokenText ->
        executeUserInstruction(spokenText)
    }

    // WebSocket Client
    val webSocketClient = OmniaWebSocketClient(viewModelScope)

    // DataStore settings
    val settings: StateFlow<OmniaSettings> = preferencesRepository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = OmniaSettings()
        )

    // Telemetry & Tasks
    private val _telemetry = MutableStateFlow(SystemTelemetry())
    val telemetry: StateFlow<SystemTelemetry> = _telemetry.asStateFlow()

    private val _textCommand = MutableStateFlow("")
    val textCommand: StateFlow<String> = _textCommand.asStateFlow()

    private val _commandFeedback = MutableStateFlow<String?>(null)
    val commandFeedback: StateFlow<String?> = _commandFeedback.asStateFlow()

    private val _tasks = MutableStateFlow<List<TaskItem>>(emptyList())
    val tasks: StateFlow<List<TaskItem>> = _tasks.asStateFlow()

    private var telemetryTickerJob: Job? = null

    init {
        refreshAllData()
        startTelemetrySimulation()
    }

    private fun refreshAllData() {
        _socialPosts.value = socialMediaOperator.getPosts()
        _orders.value = eCommerceEngine.getOrders()
        _inventory.value = eCommerceEngine.getInventory()
        _dailyReportText.value = eCommerceEngine.calculateDailyReport()
        _memoryRecords.value = memoryDatabase.getAllRecords()
        _auditLedger.value = securityGate.getAuditLedger()
        _supportedApps.value = automationDriver.discoverSupportedApps()
    }

    private fun startTelemetrySimulation() {
        telemetryTickerJob?.cancel()
        telemetryTickerJob = viewModelScope.launch {
            var counter = 0
            while (isActive) {
                delay(1200L)
                counter++
                val baseFreq = 4.18f + (kotlin.math.sin(counter.toDouble() * 0.4).toFloat() * 0.08f)
                _telemetry.value = SystemTelemetry(
                    neuralEngineReadiness = 0.998f,
                    coreFrequencyGhz = (baseFreq * 100).toInt() / 100f,
                    latencyMs = 9 + (counter % 5),
                    memoryUsageMb = 142 + (counter % 10),
                    memoryMaxMb = 4096,
                    activeSubroutines = 5 + (counter % 2),
                    networkStatus = NetworkTelemetry(
                        linkType = "L1-MESH QUANTUM LINK",
                        protocol = "OMNIA-SEC-TLS 1.3",
                        isConnected = true,
                        signalPercent = 98,
                        pingMs = 8
                    )
                )
            }
        }
    }

    // ===================================
    // MASTER WORKFLOW: USER COMMAND -> PLAN -> SECURITY -> APPROVAL -> EXECUTE -> REPORT
    // ===================================
    fun executeUserInstruction(instruction: String) {
        val trimmed = instruction.trim()
        if (trimmed.isEmpty()) return

        _textCommand.value = ""
        viewModelScope.launch {
            // Step 1: Transition to LISTENING / UNDERSTANDING
            stateMachine.transitionTo(OperatorState.LISTENING, "Instruction received: $trimmed", force = true)
            delay(600L)

            // Step 2: Transition to THINKING & Interpret Command
            stateMachine.transitionTo(OperatorState.THINKING, "Planning & Security evaluation", force = true)
            val intent = planner.interpretCommand(trimmed)
            _selectedLanguage.value = intent.detectedLanguage
            val plan = planner.buildExecutionPlan(intent)
            _activePlan.value = plan
            delay(800L)

            // Step 3: Check for L4 Prohibited Actions
            if (plan.highestRiskLevel == RiskLevel.L4) {
                stateMachine.transitionTo(OperatorState.ERROR, "Prohibited action rejected", force = true)
                _commandFeedback.value = "BLOCKED: Action classified as L4 (Security/Password violation prohibited)."
                _auditLedger.value = securityGate.getAuditLedger()
                return@launch
            }

            // Step 4: Check if Plan requires Operator Approval (L2 or L3)
            val pendingList = mutableListOf<PlannedAction>()
            for (action in plan.actions) {
                val eval = securityGate.evaluateAction(action)
                if (eval is com.omnia.app.security.ActionEvaluationResult.RequiresApproval) {
                    pendingList.add(action)
                }
            }
            _pendingApprovals.value = pendingList
            _auditLedger.value = securityGate.getAuditLedger()

            if (pendingList.isNotEmpty()) {
                stateMachine.transitionTo(OperatorState.IDLE, "Awaiting approval for ${pendingList.size} action(s)", force = true)
                _commandFeedback.value = "PLAN READY: Requires explicit approval for ${pendingList.first().title}"
                _currentScreen.value = OmniaScreen.SECURITY_CENTER
                return@launch
            }

            // Step 5: Execute Approved/Safe Actions
            stateMachine.transitionTo(OperatorState.EXECUTING, "Executing plan ${plan.planId}", force = true)
            delay(1200L)

            // Execute specific domain results based on intent
            when (intent.category) {
                com.omnia.app.brain.IntentCategory.PRODUCT_CAMPAIGN -> {
                    _visualAnalysis.value = visionEngine.analyzeImageAttributes()
                    socialMediaOperator.generateCaptions("Embroidered Cotton Dress", 2450.0, "BDT")
                    _socialPosts.value = socialMediaOperator.getPosts()
                    _commandFeedback.value = "PRODUCT CAMPAIGN READY: Visual attributes analyzed & social draft pre-staged."
                }
                com.omnia.app.brain.IntentCategory.ORDER_ANALYTICS -> {
                    _dailyReportText.value = eCommerceEngine.calculateDailyReport()
                    _commandFeedback.value = "ORDER REPORT: Today's orders & revenue calculated."
                }
                else -> {
                    _commandFeedback.value = "DIRECTIVE COMPLETED: All safe subroutines verified."
                }
            }

            // Step 6: Speaking / Reporting
            stateMachine.transitionTo(OperatorState.SPEAKING, "Reporting completion", force = true)
            voiceEngine.speak(_commandFeedback.value ?: "Task complete", _selectedLanguage.value)
            delay(1600L)

            stateMachine.resetToIdle("Workflow complete")
            refreshAllData()
        }
    }

    // ===================================
    // APPROVAL ACTIONS (L2 & L3)
    // ===================================
    fun approvePendingAction(action: PlannedAction) {
        viewModelScope.launch {
            securityGate.approveAction(action)
            _pendingApprovals.value = _pendingApprovals.value.filter { it.id != action.id }
            _auditLedger.value = securityGate.getAuditLedger()

            // Execute the action once approved
            stateMachine.transitionTo(OperatorState.EXECUTING, "Executing approved action: ${action.title}", force = true)
            delay(1000L)

            securityGate.recordVerification(action, success = true, details = "Executed & verified via authorized channel.")
            _auditLedger.value = securityGate.getAuditLedger()

            stateMachine.resetToIdle("Action execution verified")
            _commandFeedback.value = "APPROVED & EXECUTED: ${action.title}"
            refreshAllData()
        }
    }

    fun rejectPendingAction(action: PlannedAction) {
        securityGate.rejectAction(action, "User manually cancelled in Security Center")
        _pendingApprovals.value = _pendingApprovals.value.filter { it.id != action.id }
        _auditLedger.value = securityGate.getAuditLedger()
        _commandFeedback.value = "CANCELLED: ${action.title} was rejected by operator."
    }

    // ===================================
    // NAVIGATION & SCREENS
    // ===================================
    fun navigateTo(screen: OmniaScreen) {
        _currentScreen.value = screen
    }

    fun selectTab(tab: NavigationTab) {
        _selectedTab.value = tab
        _currentScreen.value = when (tab) {
            NavigationTab.HOME -> OmniaScreen.MAIN_DASHBOARD
            NavigationTab.WORKSPACE -> OmniaScreen.APP_INTEGRATIONS
            NavigationTab.TASKS -> OmniaScreen.TASK_PLANNER
            NavigationTab.BUSINESS -> OmniaScreen.BUSINESS_DASHBOARD
            NavigationTab.MEMORY -> OmniaScreen.MEMORY_MANAGER
            NavigationTab.SETTINGS -> OmniaScreen.GENERAL_SETTINGS
        }
    }

    fun setLanguage(language: OmniaLanguage) {
        _selectedLanguage.value = language
    }

    // Voice triggers
    fun onVoiceButtonClick() {
        if (currentState.value == OperatorState.LISTENING) {
            voiceEngine.stopListening()
            stateMachine.resetToIdle("Voice input stopped")
        } else {
            voiceEngine.startListening(_selectedLanguage.value)
            stateMachine.transitionTo(OperatorState.LISTENING, "Voice button trigger", force = true)
        }
    }

    // Text command triggers
    fun onTextCommandChange(text: String) {
        _textCommand.value = text
    }

    fun executeTextCommand(override: String? = null) {
        val cmd = override ?: _textCommand.value
        executeUserInstruction(cmd)
    }

    // Memory database actions
    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        _memoryRecords.value = if (query.isBlank()) {
            memoryDatabase.getAllRecords()
        } else {
            memoryDatabase.searchRecords(query)
        }
    }

    fun saveMemoryNote(key: String, value: String) {
        val record = MemoryRecord(
            category = "USER_NOTE",
            key = key,
            value = value
        )
        memoryDatabase.saveRecord(record)
        _memoryRecords.value = memoryDatabase.getAllRecords()
    }

    fun deleteMemoryRecord(id: String) {
        memoryDatabase.deleteRecord(id)
        _memoryRecords.value = memoryDatabase.getAllRecords()
    }

    fun clearAllMemory() {
        memoryDatabase.clearAll()
        _memoryRecords.value = emptyList()
    }

    // E-Commerce actions
    fun updateOrderStatus(orderId: String, status: OrderStatus) {
        eCommerceEngine.updateOrderStatus(orderId, status)
        _orders.value = eCommerceEngine.getOrders()
        _dailyReportText.value = eCommerceEngine.calculateDailyReport()
    }

    // App launch via intent
    fun launchApp(pkg: String): Result<String> {
        return automationDriver.launchAppByIntent(pkg)
    }

    // Task actions
    fun addTask(title: String, category: String, module: String) {
        val newTask = TaskItem(
            id = "TSK-${UUID.randomUUID().toString().take(4).uppercase()}",
            title = title,
            category = category,
            status = TaskStatus.RUNNING,
            progress = 0.10f,
            executionTimeSec = 0,
            targetModule = module
        )
        val current = _tasks.value.toMutableList()
        current.add(0, newTask)
        _tasks.value = current
    }

    fun toggleTaskStatus(taskId: String) {
        val updated = _tasks.value.map { task ->
            if (task.id == taskId) {
                val nextStatus = when (task.status) {
                    TaskStatus.PENDING -> TaskStatus.RUNNING
                    TaskStatus.RUNNING -> TaskStatus.COMPLETED
                    TaskStatus.COMPLETED -> TaskStatus.PENDING
                    TaskStatus.SUSPENDED -> TaskStatus.RUNNING
                }
                val progress = if (nextStatus == TaskStatus.COMPLETED) 1.0f else task.progress
                task.copy(status = nextStatus, progress = progress)
            } else {
                task
            }
        }
        _tasks.value = updated
    }

    // Dev demo controls
    fun transitionState(target: OperatorState, force: Boolean = false) {
        stateMachine.transitionTo(target, "Dev Panel", force = force)
    }

    fun toggleAutoDemo() {
        stateMachine.toggleAutoDemo()
    }

    fun resetCore() {
        stateMachine.resetToIdle()
    }

    // Settings
    fun setParticlesEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.updateParticlesEnabled(enabled) }
    }

    fun setParticleDensity(density: Int) {
        viewModelScope.launch { preferencesRepository.updateParticleDensity(density) }
    }

    fun setCorePulseSpeed(speed: Float) {
        viewModelScope.launch { preferencesRepository.updateCorePulseSpeed(speed) }
    }

    fun setHapticFeedback(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.updateHapticFeedback(enabled) }
    }

    fun setOperatorName(name: String) {
        viewModelScope.launch { preferencesRepository.updateOperatorName(name) }
    }

    fun resetSettings() {
        viewModelScope.launch { preferencesRepository.resetToDefaults() }
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.destroy()
        webSocketClient.disconnect()
    }
}
