package com.example.omnia.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeviceHub
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnia.viewmodel.OmniaViewModel
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaEmerald
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OmniaVoidBlack
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@Composable
fun WorkspaceScreen(
    viewModel: OmniaViewModel,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OmniaVoidBlack)
            .padding(16.dp)
            .testTag("workspace_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header
            Column {
                Text(
                    text = "OPERATOR WORKSPACE",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontFamily = OrbitronFamily,
                        color = OmniaCyanPrimary,
                        fontSize = 22.sp
                    )
                )
                Text(
                    text = "MODULAR ARCHITECTURE // EXTENSIBLE PIPELINE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = RajdhaniFamily,
                        letterSpacing = 1.2.sp,
                        color = OmniaTextMuted
                    )
                )
            }
        }

        // Phase 1 Architecture Banner
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = OmniaSurface,
                border = BorderStroke(1.dp, OmniaCyanPrimary.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Phase 1 Notice",
                        tint = OmniaCyanPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "PHASE 1 SPECIFICATION",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaCyanPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Core state machine, telemetry bus, and responsive sci-fi HUD active. External app automation drivers remain modular stubs pending Phase 2 system driver staging. Zero simulated mocks.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextSecondary,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }

        // Extensible Core Modules
        item {
            Text(
                text = "OPERATOR SUBSYSTEMS",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontFamily = OrbitronFamily,
                    color = OmniaCyanPrimary,
                    fontSize = 12.sp
                )
            )
        }

        item {
            ModuleCard(
                title = "State Machine & Telemetry Bus",
                status = "ACTIVE (CORE)",
                statusColor = OmniaEmerald,
                description = "6-state operational engine with atomic transition verification, activity log journal, and UI reactive flows.",
                icon = Icons.Default.Layers,
                tags = listOf("OperatorState", "StateFlow", "TelemetryEngine")
            )
        }

        item {
            ModuleCard(
                title = "Context & Posture Engine",
                status = "STANDBY (PHASE 1)",
                statusColor = OmniaCyanPrimary,
                description = "Aggregates local device orientation, battery telemetry, and local operator activity into a unified state vector.",
                icon = Icons.Default.Psychology,
                tags = listOf("ContextBroker", "HALObserver", "SensorBus")
            )
        }

        item {
            ModuleCard(
                title = "App Ecosystem Bridge",
                status = "EXTENSIBLE STUB",
                statusColor = OmniaTextMuted,
                description = "Driver interface designed for future intent mapping and cross-app workflow orchestration. No fake automation.",
                icon = Icons.Default.DeviceHub,
                tags = listOf("IntentDriverStub", "AppBridgeAPI", "ActionGraph")
            )
        }

        item {
            ModuleCard(
                title = "Security & Permission Sandbox",
                status = "ZERO-TRUST ACTIVE",
                statusColor = OmniaEmerald,
                description = "Least-privilege isolation preventing unnecessary runtime permissions or unauthenticated execution.",
                icon = Icons.Default.Lock,
                tags = listOf("ZeroTrust", "PrivacyFence", "PermissionGuard")
            )
        }

        item {
            ModuleCard(
                title = "Perception & Vision Pipeline",
                status = "ROADMAP STUB",
                statusColor = OmniaTextMuted,
                description = "Architectural interface prepared for on-device screen parsing in Phase 3. Stubs ready for extension.",
                icon = Icons.Default.Visibility,
                tags = listOf("ScreenParserAPI", "AccessibilityDriverStub")
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ModuleCard(
    title: String,
    status: String,
    statusColor: androidx.compose.ui.graphics.Color,
    description: String,
    icon: ImageVector,
    tags: List<String>,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = OmniaCyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = OrbitronFamily,
                            color = OmniaTextPrimary,
                            fontSize = 13.sp
                        )
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = OmniaDarkNavy,
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = status,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = RajdhaniFamily,
                            fontWeight = FontWeight.Bold,
                            color = statusColor,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = RajdhaniFamily,
                    color = OmniaTextSecondary,
                    fontSize = 12.sp
                )
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                tags.forEach { tag ->
                    Surface(
                        shape = RoundedCornerShape(3.dp),
                        color = OmniaDarkNavy,
                        border = BorderStroke(1.dp, OmniaBorder.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "#$tag",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = RajdhaniFamily,
                                color = OmniaTextMuted,
                                fontSize = 9.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
