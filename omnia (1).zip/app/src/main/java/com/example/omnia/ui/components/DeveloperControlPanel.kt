package com.example.omnia.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnia.model.OperatorState
import com.example.ui.theme.OmniaBorder
import com.example.ui.theme.OmniaBorderBright
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaDarkNavy
import com.example.ui.theme.OmniaSurface
import com.example.ui.theme.OmniaSurfaceElevated
import com.example.ui.theme.OmniaTextCyan
import com.example.ui.theme.OmniaTextMuted
import com.example.ui.theme.OmniaTextPrimary
import com.example.ui.theme.OmniaTextSecondary
import com.example.ui.theme.OrbitronFamily
import com.example.ui.theme.RajdhaniFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeveloperControlPanel(
    currentState: OperatorState,
    isAutoDemoRunning: Boolean,
    lastTransitionMessage: String,
    onStateSelect: (OperatorState) -> Unit,
    onToggleAutoDemo: () -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("developer_control_panel"),
        shape = RoundedCornerShape(12.dp),
        color = OmniaSurface,
        border = BorderStroke(1.dp, OmniaBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header with badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(currentState.accentColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "STATE MACHINE // DEV CONTROLS",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontSize = 12.sp,
                            color = OmniaCyanPrimary
                        )
                    )
                }

                // Status chip
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = OmniaSurfaceElevated,
                    border = BorderStroke(1.dp, currentState.accentColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = currentState.code,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = currentState.accentColor
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // State selector chips
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OperatorState.entries.forEach { state ->
                    val isSelected = (state == currentState)
                    val bgColor by animateColorAsState(
                        targetValue = if (isSelected) state.accentColor.copy(alpha = 0.22f) else OmniaDarkNavy,
                        label = "state_chip_bg"
                    )
                    val borderColor by animateColorAsState(
                        targetValue = if (isSelected) state.accentColor else OmniaBorder,
                        label = "state_chip_border"
                    )

                    Box(
                        modifier = Modifier
                            .testTag("dev_state_btn_${state.name.lowercase()}")
                            .clip(RoundedCornerShape(6.dp))
                            .background(bgColor)
                            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
                            .clickable { onStateSelect(state) }
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(state.accentColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = state.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontFamily = OrbitronFamily,
                                    color = if (isSelected) state.accentColor else OmniaTextSecondary
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action triggers (Auto Cycle Demo & Reset Core)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Auto Cycle Toggle Button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dev_btn_auto_demo")
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isAutoDemoRunning) OmniaCyanPrimary.copy(alpha = 0.2f) else OmniaDarkNavy)
                        .border(
                            1.dp,
                            if (isAutoDemoRunning) OmniaCyanPrimary else OmniaBorderBright,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onToggleAutoDemo() }
                        .padding(vertical = 10.dp, horizontal = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Autorenew,
                            contentDescription = "Auto Cycle",
                            tint = if (isAutoDemoRunning) OmniaCyanPrimary else OmniaTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAutoDemoRunning) "PAUSE DEMO" else "AUTO-CYCLE DEMO",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = OrbitronFamily,
                                color = if (isAutoDemoRunning) OmniaCyanPrimary else OmniaTextPrimary
                            )
                        )
                    }
                }

                // Reset Button
                Box(
                    modifier = Modifier
                        .testTag("dev_btn_reset_core")
                        .clip(RoundedCornerShape(8.dp))
                        .background(OmniaDarkNavy)
                        .border(1.dp, OmniaBorderBright, RoundedCornerShape(8.dp))
                        .clickable { onReset() }
                        .padding(vertical = 10.dp, horizontal = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset",
                            tint = OmniaTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "RESET IDLE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = OrbitronFamily,
                                color = OmniaTextSecondary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Transition Log Output
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                color = OmniaDarkNavy,
                border = BorderStroke(1.dp, OmniaBorder.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "> ",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = OmniaCyanPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = lastTransitionMessage,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = RajdhaniFamily,
                            color = OmniaTextMuted,
                            fontSize = 12.sp
                        ),
                        maxLines = 1
                    )
                }
            }
        }
    }
}
