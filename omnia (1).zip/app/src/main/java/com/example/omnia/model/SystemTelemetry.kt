package com.example.omnia.model

data class SystemTelemetry(
    val neuralEngineReadiness: Float = 0.998f, // 99.8%
    val coreFrequencyGhz: Float = 4.2f,
    val latencyMs: Int = 11,
    val memoryUsageMb: Int = 142,
    val memoryMaxMb: Int = 4096,
    val activeSubroutines: Int = 4,
    val networkStatus: NetworkTelemetry = NetworkTelemetry()
)

data class NetworkTelemetry(
    val linkType: String = "L1-MESH QUANTUM LINK",
    val protocol: String = "OMNIA-SEC-TLS 1.3",
    val isConnected: Boolean = true,
    val signalPercent: Int = 98,
    val pingMs: Int = 8
)

data class ActivityLog(
    val id: String,
    val timestamp: String,
    val state: OperatorState,
    val message: String,
    val isAnomaly: Boolean = false
)

enum class TaskStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    SUSPENDED
}

data class TaskItem(
    val id: String,
    val title: String,
    val category: String,
    val status: TaskStatus,
    val progress: Float, // 0.0 to 1.0
    val executionTimeSec: Int,
    val targetModule: String
)

data class OmniaSettings(
    val particlesEnabled: Boolean = true,
    val particleDensity: Int = 45, // 20..80
    val corePulseSpeed: Float = 1.0f, // 0.5f..2.0f
    val hapticFeedbackEnabled: Boolean = true,
    val autoCycleDemo: Boolean = false,
    val operatorName: String = "OMNIA-ALPHA-01",
    val telemetryRefreshRateMs: Long = 1000L
)
