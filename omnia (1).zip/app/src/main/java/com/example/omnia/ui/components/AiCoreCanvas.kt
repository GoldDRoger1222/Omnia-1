package com.example.omnia.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.omnia.model.OperatorState
import com.example.ui.theme.OmniaCyanGlow
import com.example.ui.theme.OmniaCyanPrimary
import com.example.ui.theme.OmniaTextPrimary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AiCoreCanvas(
    state: OperatorState,
    modifier: Modifier = Modifier,
    size: Dp = 230.dp,
    speedMultiplier: Float = 1.0f,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "omnia_core_anim")

    // Dynamic rotation speeds adjusted for state
    val baseRotationDuration = (12000 / (state.pulseSpeedMultiplier * speedMultiplier)).toInt().coerceAtLeast(1500)
    val fastRotationDuration = (4000 / (state.pulseSpeedMultiplier * speedMultiplier)).toInt().coerceAtLeast(800)
    val pulseDuration = (2200 / (state.pulseSpeedMultiplier * speedMultiplier)).toInt().coerceAtLeast(500)

    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(baseRotationDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rotation"
    )

    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(fastRotationDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val rippleProgress by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween((pulseDuration * 1.5).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ripple_progress"
    )

    // Smooth state color transitions
    val animatedAccentColor by animateColorAsState(
        targetValue = state.accentColor,
        animationSpec = tween(500),
        label = "core_accent_color"
    )

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .size(size)
            .testTag("ai_core_canvas")
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val maxRadius = this.size.width / 2f

            // 1. Outermost aura glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        animatedAccentColor.copy(alpha = 0.28f),
                        animatedAccentColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius * pulseScale
                ),
                radius = maxRadius * pulseScale,
                center = center
            )

            // 2. Ripple waves for LISTENING / SPEAKING states
            if (state == OperatorState.LISTENING || state == OperatorState.SPEAKING) {
                val rippleAlpha = (1.25f - rippleProgress).coerceIn(0f, 0.6f)
                drawCircle(
                    color = animatedAccentColor.copy(alpha = rippleAlpha),
                    radius = maxRadius * rippleProgress * 0.95f,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
                drawCircle(
                    color = OmniaCyanGlow.copy(alpha = rippleAlpha * 0.7f),
                    radius = maxRadius * (rippleProgress * 0.7f),
                    center = center,
                    style = Stroke(width = 1.5f.dp.toPx())
                )
            }

            // 3. Outer Segmented Reticle Ring
            rotate(outerRotation, center) {
                drawOuterSegmentedRing(
                    center = center,
                    radius = maxRadius * 0.88f,
                    color = animatedAccentColor.copy(alpha = 0.75f),
                    state = state
                )
            }

            // 4. Middle Counter-Rotating Orbital Ring
            rotate(innerRotation, center) {
                drawMiddleOrbitalRing(
                    center = center,
                    radius = maxRadius * 0.70f,
                    color = animatedAccentColor,
                    state = state
                )
            }

            // 5. High-tech Gyroscope Grid / Radial Ticks
            rotate(outerRotation * 0.5f, center) {
                drawTechReticle(
                    center = center,
                    radius = maxRadius * 0.55f,
                    color = animatedAccentColor.copy(alpha = 0.5f)
                )
            }

            // 6. Central Glowing Energy Core
            val coreRadius = maxRadius * 0.40f * pulseScale
            drawCentralCore(
                center = center,
                radius = coreRadius,
                accentColor = animatedAccentColor,
                state = state
            )

            // 7. Error hazard markers if in ERROR state
            if (state == OperatorState.ERROR) {
                drawErrorHazardOverlay(center, maxRadius * 0.78f, animatedAccentColor)
            }
        }
    }
}

private fun DrawScope.drawOuterSegmentedRing(
    center: Offset,
    radius: Float,
    color: Color,
    state: OperatorState
) {
    val strokeWidth = 2.dp.toPx()
    val segmentCount = 6
    val sweepAngle = 44f
    val gap = 16f

    for (i in 0 until segmentCount) {
        val startAngle = i * (sweepAngle + gap)
        drawArc(
            color = color,
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
    }

    // Outer corner bracket notches
    val notchDistance = radius + 6.dp.toPx()
    for (angleDeg in listOf(45f, 135f, 225f, 315f)) {
        val rad = angleDeg * PI / 180f
        val nx = center.x + (notchDistance * cos(rad)).toFloat()
        val ny = center.y + (notchDistance * sin(rad)).toFloat()
        drawCircle(
            color = color,
            radius = 2.dp.toPx(),
            center = Offset(nx, ny)
        )
    }
}

private fun DrawScope.drawMiddleOrbitalRing(
    center: Offset,
    radius: Float,
    color: Color,
    state: OperatorState
) {
    // Continuous thin orbital track
    drawCircle(
        color = color.copy(alpha = 0.35f),
        radius = radius,
        center = center,
        style = Stroke(width = 1.dp.toPx())
    )

    // Orbital planetary energy nodes at 0, 90, 180, 270
    val nodeAngles = listOf(0f, 90f, 180f, 270f)
    for (angle in nodeAngles) {
        val rad = angle * PI / 180f
        val x = center.x + (radius * cos(rad)).toFloat()
        val y = center.y + (radius * sin(rad)).toFloat()

        // Outer glow
        drawCircle(
            color = color.copy(alpha = 0.4f),
            radius = 5.dp.toPx(),
            center = Offset(x, y)
        )
        // Solid bead
        drawCircle(
            color = Color.White,
            radius = 2.5f.dp.toPx(),
            center = Offset(x, y)
        )
    }
}

private fun DrawScope.drawTechReticle(
    center: Offset,
    radius: Float,
    color: Color
) {
    // 12 precision dial ticks
    val tickLength = 5.dp.toPx()
    for (i in 0 until 12) {
        val rad = (i * 30f) * PI / 180f
        val rInner = radius - tickLength
        val rOuter = radius
        val p1 = Offset(center.x + (rInner * cos(rad)).toFloat(), center.y + (rInner * sin(rad)).toFloat())
        val p2 = Offset(center.x + (rOuter * cos(rad)).toFloat(), center.y + (rOuter * sin(rad)).toFloat())
        drawLine(
            color = color,
            start = p1,
            end = p2,
            strokeWidth = 1.2.dp.toPx()
        )
    }
}

private fun DrawScope.drawCentralCore(
    center: Offset,
    radius: Float,
    accentColor: Color,
    state: OperatorState
) {
    // Multi-stage radial gradient
    val coreBrush = Brush.radialGradient(
        colors = listOf(
            Color.White,
            OmniaTextPrimary,
            accentColor,
            accentColor.copy(alpha = 0.45f),
            Color.Transparent
        ),
        center = center,
        radius = radius
    )

    drawCircle(
        brush = coreBrush,
        radius = radius,
        center = center
    )

    // Inner bright singularity
    drawCircle(
        color = Color.White.copy(alpha = 0.95f),
        radius = radius * 0.22f,
        center = center
    )
    drawCircle(
        color = OmniaCyanPrimary,
        radius = radius * 0.35f,
        center = center,
        style = Stroke(width = 1.5f.dp.toPx())
    )
}

private fun DrawScope.drawErrorHazardOverlay(
    center: Offset,
    radius: Float,
    color: Color
) {
    // Draw 3 caution triangles
    val triangleCount = 3
    for (i in 0 until triangleCount) {
        val angle = (i * 120f) * PI / 180f
        val dist = radius * 0.95f
        val tipX = center.x + (dist * cos(angle)).toFloat()
        val tipY = center.y + (dist * sin(angle)).toFloat()

        val p = Path().apply {
            moveTo(tipX, tipY)
            lineTo(tipX - 10f, tipY + 16f)
            lineTo(tipX + 10f, tipY + 16f)
            close()
        }
        drawPath(
            path = p,
            color = color,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
