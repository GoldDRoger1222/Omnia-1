package com.omnia.app.core

/**
 * Supported UI and Interaction Languages for OMNIA Mobile Operator.
 */
enum class OmniaLanguage(
    val code: String,
    val displayName: String,
    val nativeLabel: String
) {
    ENGLISH(
        code = "en",
        displayName = "English",
        nativeLabel = "English"
    ),
    BANGLA(
        code = "bn",
        displayName = "Bangla",
        nativeLabel = "বাংলা"
    ),
    BANGLISH(
        code = "bng",
        displayName = "Banglish",
        nativeLabel = "Banglish (Phonetic)"
    );

    companion object {
        fun fromCode(code: String): OmniaLanguage =
            entries.find { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
    }
}

/**
 * Multilingual phrase dictionary providing instant localized strings.
 */
object OmniaLocalization {
    fun getString(key: String, language: OmniaLanguage): String {
        return when (language) {
            OmniaLanguage.BANGLA -> banglaStrings[key] ?: englishStrings[key] ?: key
            OmniaLanguage.BANGLISH -> banglishStrings[key] ?: englishStrings[key] ?: key
            OmniaLanguage.ENGLISH -> englishStrings[key] ?: key
        }
    }

    private val englishStrings = mapOf(
        "app_title" to "OMNIA",
        "tagline" to "UNIVERSAL AI MOBILE OPERATOR",
        "voice_prompt_hint" to "Tap mic or say 'OMNIA...'",
        "text_input_placeholder" to "Enter operator directive...",
        "status_idle" to "IDLE (STANDBY)",
        "status_listening" to "LISTENING",
        "status_thinking" to "THINKING",
        "status_executing" to "EXECUTING",
        "status_speaking" to "SPEAKING",
        "status_error" to "ERROR (ANOMALY)",
        "sample_cmd_1" to "OMNIA, prepare product campaign for this dress",
        "sample_cmd_2" to "OMNIA, analyze today's business orders",
        "risk_l0" to "L0: Read-Only",
        "risk_l1" to "L1: Reversible Draft",
        "risk_l2" to "L2: External Publish (Requires Approval)",
        "risk_l3" to "L3: Financial/Order (Explicit Approval)",
        "risk_l4" to "L4: Prohibited Security Action",
        "approval_required" to "APPROVAL REQUIRED",
        "approve_btn" to "APPROVE",
        "reject_btn" to "REJECT",
        "offline_notice" to "Offline Mode Active • Local Rules Enforced"
    )

    private val banglaStrings = mapOf(
        "app_title" to "অমনিয়া",
        "tagline" to "সর্বজনীন এআই মোবাইল অপারেটর",
        "voice_prompt_hint" to "মাইকে চাপুন বা বলুন 'OMNIA...'",
        "text_input_placeholder" to "অপারেটর নির্দেশ লিখুন...",
        "status_idle" to "অপেক্ষারত (স্ট্যান্ডবাই)",
        "status_listening" to "শুনছে...",
        "status_thinking" to "চিন্তা করছে...",
        "status_executing" to "সম্পাদন করছে...",
        "status_speaking" to "বলছে...",
        "status_error" to "ত্রুটি (অ্যানোমালি)",
        "sample_cmd_1" to "OMNIA, এই ড্রেস এর প্রোডাক্ট ক্যাম্পেইন রেডি কর",
        "sample_cmd_2" to "OMNIA, আমার বিজনেসের আজকের অর্ডারগুলা অ্যানালাইজ কর",
        "risk_l0" to "L0: শুধুমাত্র পাঠ্য",
        "risk_l1" to "L1: রিভার্সিবল ড্রাফট",
        "risk_l2" to "L2: সোশ্যাল পাবলিশ (অনুমোদন প্রয়োজন)",
        "risk_l3" to "L3: আর্থিক/অর্ডার (অনুমোদন প্রয়োজন)",
        "risk_l4" to "L4: নিষিদ্ধ সিকিউরিটি অ্যাকশন",
        "approval_required" to "অনুমোদন প্রয়োজন",
        "approve_btn" to "অনুমোদন করুন",
        "reject_btn" to "বাতিল করুন",
        "offline_notice" to "অফলাইন মোড সক্রিয় • লোকাল নিয়ম প্রযোজ্য"
    )

    private val banglishStrings = mapOf(
        "app_title" to "OMNIA",
        "tagline" to "UNIVERSAL AI MOBILE OPERATOR",
        "voice_prompt_hint" to "Mic e tap korun ba bolun 'OMNIA...'",
        "text_input_placeholder" to "Operator directive likhun...",
        "status_idle" to "IDLE (STANDBY)",
        "status_listening" to "LISTENING...",
        "status_thinking" to "THINKING...",
        "status_executing" to "EXECUTING...",
        "status_speaking" to "SPEAKING...",
        "status_error" to "ERROR (ANOMALY)",
        "sample_cmd_1" to "OMNIA, ei dress er product campaign ready kor",
        "sample_cmd_2" to "OMNIA, amar business er ajker order gula analyze kor",
        "risk_l0" to "L0: Shudhu Pora",
        "risk_l1" to "L1: Reversible Draft",
        "risk_l2" to "L2: External Publish (Approval Dorkar)",
        "risk_l3" to "L3: Financial/Order (Explicit Approval)",
        "risk_l4" to "L4: Prohibited Security Action",
        "approval_required" to "APPROVAL DORKAR",
        "approve_btn" to "APPROVE KORUN",
        "reject_btn" to "CANCEL KORUN",
        "offline_notice" to "Offline Mode Active • Local Rules Projojjo"
    )
}
