# OMNIA — Deployment & Setup Guide

## 1. Phone-First Android Setup
1. Open the project in Android Studio (Ladybug / Iguana or later).
2. Connect your Android device via USB or Wi-Fi debugging (minimum SDK 24, target SDK 36).
3. Build and install:
   ```bash
   gradle :app:installDebug
   ```
4. Grant Audio Recording runtime permission when prompted to use the Voice Engine.
5. (Optional) To enable the Universal Mobile Operator UI navigation, open **Settings → Accessibility → Installed Apps → OMNIA** and toggle on with user consent.

---

## 2. Python Backend Deployment

### Local Development
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Docker Deployment
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY backend/ backend/
EXPOSE 8000
CMD ["uvicorn", "backend.app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```
